import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { villageAt, villageGroundClear } from "./villages";
import { onSettlementRoad } from "./routes";
import { sceneryGroundClear } from "./scenery";

type VegetationOptions = {
  scene: THREE.Scene;
  heightAt: (x: number, z: number) => number;
  lakeAt: (x: number, z: number) => number;
  trailAt: (z: number) => number;
  wind: { value: number };
};

type Instance = {
  x: number;
  y: number;
  z: number;
  rotation: number;
  sx: number;
  sy: number;
  sz: number;
  tint?: number;
};

type VegetationChunk = { group: THREE.Group; detail: boolean };

function hash(x: number, z: number) {
  const value = Math.sin(x * 127.1 + z * 311.7) * 43758.5453123;
  return value - Math.floor(value);
}

function noise(x: number, z: number) {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const ux = fx * fx * (3 - 2 * fx);
  const uz = fz * fz * (3 - 2 * fz);
  return THREE.MathUtils.lerp(
    THREE.MathUtils.lerp(hash(ix, iz), hash(ix + 1, iz), ux),
    THREE.MathUtils.lerp(hash(ix, iz + 1), hash(ix + 1, iz + 1), ux),
    uz,
  );
}

function paint(geometry: THREE.BufferGeometry, color: string, seed: number) {
  const base = new THREE.Color(color);
  const colors = new Float32Array(geometry.attributes.position.count * 3);
  for (let i = 0; i < geometry.attributes.position.count; i += 1) {
    const shade = 0.82 + hash(Math.floor(i / 3), seed) * 0.3;
    colors[i * 3] = base.r * shade;
    colors[i * 3 + 1] = base.g * shade;
    colors[i * 3 + 2] = base.b * shade;
  }
  geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
  return geometry;
}

function pineGeometry(detailed: boolean) {
  const pieces: THREE.BufferGeometry[] = [];
  const tiers = detailed ? 8 : 4;
  for (let i = 0; i < tiers; i += 1) {
    const t = i / tiers;
    const radius = 2.5 * Math.pow(1 - t, 0.8) + 0.15;
    const height = detailed ? 2.8 - t * 0.6 : 4 - t;
    const geometry = new THREE.ConeGeometry(radius, height, detailed ? 8 : 6, 1).toNonIndexed();
    geometry.rotateY(i * 0.37);
    geometry.translate(0, 2.5 + t * 6.2, 0);
    pieces.push(paint(geometry, i % 3 === 0 ? "#42664a" : i % 3 === 1 ? "#4f7653" : "#5c815b", i + 7));
  }
  const result = mergeGeometries(pieces)!;
  pieces.forEach((piece) => piece.dispose());
  return result;
}

function broadleafGeometry(detailed: boolean) {
  const clusters = detailed
    ? [[0, 6.2, 0, 2.1], [-1.4, 5.7, 0.3, 1.55], [1.4, 5.9, -0.2, 1.65], [0.1, 7.5, 0, 1.7], [0.3, 5.8, 1.25, 1.4]]
    : [[0, 6.1, 0, 2.45], [0, 7.4, 0, 1.7]];
  const pieces = clusters.map(([x, y, z, radius], index) => {
    const geometry = new THREE.IcosahedronGeometry(radius, detailed ? 1 : 0);
    geometry.scale(1, 0.75 + index * 0.03, 1);
    geometry.translate(x, y, z);
    return paint(geometry, index % 2 ? "#6b895e" : "#5b7d55", index + 21);
  });
  const result = mergeGeometries(pieces)!;
  pieces.forEach((piece) => piece.dispose());
  return result;
}

function grassGeometry() {
  const vertices: number[] = [];
  const colors: number[] = [];
  const shades = [new THREE.Color("#718b50"), new THREE.Color("#91a861"), new THREE.Color("#b1b87a")];
  for (let i = 0; i < 7; i += 1) {
    const angle = i / 7 * Math.PI * 2;
    const x = Math.cos(angle) * (0.1 + hash(i, 3) * 0.36);
    const z = Math.sin(angle) * (0.1 + hash(i, 4) * 0.36);
    const dx = Math.cos(angle + 0.8) * 0.07;
    const dz = Math.sin(angle + 0.8) * 0.07;
    const height = 0.42 + hash(i, 11) * 0.62;
    const bendX = Math.cos(angle) * 0.18;
    const bendZ = Math.sin(angle) * 0.18;
    const points = [
      x - dx, 0, z - dz, x + dx, 0, z + dz, x - dx * 0.55 + bendX * 0.45, height * 0.6, z - dz * 0.55 + bendZ * 0.45,
      x + dx, 0, z + dz, x + dx * 0.55 + bendX * 0.45, height * 0.6, z + dz * 0.55 + bendZ * 0.45, x - dx * 0.55 + bendX * 0.45, height * 0.6, z - dz * 0.55 + bendZ * 0.45,
      x - dx * 0.55 + bendX * 0.45, height * 0.6, z - dz * 0.55 + bendZ * 0.45, x + dx * 0.55 + bendX * 0.45, height * 0.6, z + dz * 0.55 + bendZ * 0.45, x + bendX, height, z + bendZ,
    ];
    vertices.push(...points);
    const color = shades[i % shades.length];
    for (let vertex = 0; vertex < 9; vertex += 1) {
      const shade = vertex < 2 ? 0.76 : vertex === 8 ? 1.08 : 0.94;
      colors.push(color.r * shade, color.g * shade, color.b * shade);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(vertices, 3));
  geometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 3));
  geometry.computeVertexNormals();
  return geometry;
}

function bushGeometry() {
  const pieces = [[-0.55, 0.55, 0, 0.85], [0.45, 0.65, 0.1, 0.95], [0, 0.9, -0.3, 0.8]].map(([x, y, z, radius], index) => {
    const geometry = new THREE.IcosahedronGeometry(radius, 1);
    geometry.scale(1, 0.7, 1);
    geometry.translate(x, y, z);
    return paint(geometry, index === 1 ? "#789565" : "#678658", index + 54);
  });
  const result = mergeGeometries(pieces)!;
  pieces.forEach((piece) => piece.dispose());
  return result;
}

function flowerGeometry() {
  const stem = new THREE.CylinderGeometry(0.018, 0.025, 0.62, 4).toNonIndexed();
  stem.translate(0, 0.31, 0);
  const petals = new THREE.IcosahedronGeometry(0.14, 0);
  petals.scale(1.2, 0.55, 1.2);
  petals.translate(0, 0.65, 0);
  paint(stem, "#708c53", 1);
  paint(petals, "#f4e6b1", 2);
  const result = mergeGeometries([stem, petals])!;
  stem.dispose();
  petals.dispose();
  return result;
}

function mushroomGeometry() {
  const stem = new THREE.CylinderGeometry(0.06, 0.08, 0.3, 6).toNonIndexed();
  stem.translate(0, 0.15, 0);
  const cap = new THREE.SphereGeometry(0.23, 8, 4, 0, Math.PI * 2, 0, Math.PI / 2).toNonIndexed();
  cap.scale(1, 0.55, 1);
  cap.translate(0, 0.3, 0);
  paint(stem, "#e8dcc1", 4);
  paint(cap, "#a16f52", 5);
  const result = mergeGeometries([stem, cap])!;
  stem.dispose();
  cap.dispose();
  return result;
}

function windMaterial(wind: { value: number }, strength: number) {
  const material = new THREE.MeshLambertMaterial({ vertexColors: true, side: THREE.DoubleSide });
  material.onBeforeCompile = (shader) => {
    shader.uniforms.uWindTime = wind;
    shader.vertexShader = `uniform float uWindTime;\n${shader.vertexShader}`;
    shader.vertexShader = shader.vertexShader.replace(
      "#include <begin_vertex>",
      `#include <begin_vertex>
      #ifdef USE_INSTANCING
        float breeze = sin(uWindTime * 0.7 + instanceMatrix[3].x * 0.11 + instanceMatrix[3].z * 0.08);
        transformed.x += breeze * ${strength.toFixed(3)} * max(position.y, 0.0);
        transformed.z += cos(uWindTime * 0.45 + instanceMatrix[3].z * 0.1) * ${strength.toFixed(3)} * 0.35 * max(position.y, 0.0);
      #endif`,
    );
  };
  return material;
}

export class VegetationManager {
  private options: VegetationOptions;
  private chunks = new Map<string, VegetationChunk>();
  private centerKey = "";
  private detailRadius = 2;
  private treeRadius = 3;
  private pine = pineGeometry(true);
  private pineLow = pineGeometry(false);
  private broadleaf = broadleafGeometry(true);
  private broadleafLow = broadleafGeometry(false);
  private trunk = new THREE.CylinderGeometry(0.21, 0.38, 5.1, 7);
  private grass = grassGeometry();
  private bush = bushGeometry();
  private flower = flowerGeometry();
  private mushroom = mushroomGeometry();
  private rock = new THREE.IcosahedronGeometry(1, 1);
  private log = new THREE.CylinderGeometry(0.28, 0.38, 3.5, 7);
  private contact = new THREE.CircleGeometry(1, 12);
  private leavesMaterial: THREE.MeshLambertMaterial;
  private grassMaterial: THREE.MeshLambertMaterial;
  private barkMaterial = new THREE.MeshStandardMaterial({ color: "#77664d", roughness: 1 });
  private rockMaterial = new THREE.MeshStandardMaterial({ color: "#9b9d8e", roughness: 1, flatShading: true });
  private flowerMaterial = new THREE.MeshLambertMaterial({ vertexColors: true, flatShading: true });
  private groundShadowMaterial = new THREE.MeshBasicMaterial({ color: "#253a29", transparent: true, opacity: 0.14, depthWrite: false });

  constructor(options: VegetationOptions) {
    this.options = options;
    this.trunk.translate(0, 2.55, 0);
    this.log.rotateZ(Math.PI / 2);
    this.contact.rotateX(-Math.PI / 2);
    this.leavesMaterial = windMaterial(options.wind, 0.012);
    this.grassMaterial = windMaterial(options.wind, 0.13);
  }

  setLowDetail(low: boolean) {
    const detail = low ? 1 : 2;
    const radius = low ? 1 : 3;
    if (detail === this.detailRadius && radius === this.treeRadius) return;
    this.detailRadius = detail;
    this.treeRadius = radius;
    this.centerKey = "";
  }

  private makeMesh(geometry: THREE.BufferGeometry, material: THREE.Material, instances: Instance[], castShadow = false) {
    if (!instances.length) return null;
    const mesh = new THREE.InstancedMesh(geometry, material, instances.length);
    const dummy = new THREE.Object3D();
    const color = new THREE.Color();
    instances.forEach((item, index) => {
      dummy.position.set(item.x, item.y, item.z);
      dummy.rotation.set(0, item.rotation, 0);
      dummy.scale.set(item.sx, item.sy, item.sz);
      dummy.updateMatrix();
      mesh.setMatrixAt(index, dummy.matrix);
      if (item.tint !== undefined) {
        color.setHSL(0.28 + item.tint * 0.045, 0.08 + item.tint * 0.08, 0.84 + item.tint * 0.13);
        mesh.setColorAt(index, color);
      }
    });
    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
    mesh.castShadow = castShadow;
    mesh.receiveShadow = castShadow;
    mesh.computeBoundingSphere();
    return mesh;
  }

  private createChunk(cx: number, cz: number, detail: boolean): VegetationChunk {
    const size = 100;
    const group = new THREE.Group();
    group.name = "vegetation-chunk";
    group.position.set(cx * size, 0, cz * size);
    const pines: Instance[] = [];
    const broadleaves: Instance[] = [];
    const trunks: Instance[] = [];
    const shadows: Instance[] = [];
    const grasses: Instance[] = [];
    const bushes: Instance[] = [];
    const flowers: Instance[] = [];
    const mushrooms: Instance[] = [];
    const rocks: Instance[] = [];
    const logs: Instance[] = [];
    const add = (x: number, y: number, z: number, scale: number, rotation: number, tint?: number): Instance =>
      ({ x, y, z, rotation, sx: scale, sy: scale, sz: scale, tint });

    for (let i = 0; i < 32; i += 1) {
      const seed = cx * 7141 + cz * 3137 + i * 73;
      const localX = hash(seed, 1) * size;
      const localZ = hash(seed, 2) * size;
      const x = cx * size + localX;
      const z = cz * size + localZ;
      const forest = noise(x * 0.008 + 4, z * 0.008 - 8);
      if (Math.abs(x - this.options.trailAt(z)) < 16 + hash(seed, 3) * 13 ||
          villageAt(x, z, 80) || onSettlementRoad(x, z, 5) || sceneryGroundClear(x, z, 6) || this.options.lakeAt(x, z) > 0.12 ||
          hash(seed, 4) > 0.28 + forest * 0.66) continue;
      const ground = this.options.heightAt(x, z);
      if (ground > 64) continue;
      const scale = 0.8 + hash(seed, 5) * 1.15;
      const rotation = hash(seed, 6) * Math.PI * 2;
      const tree = add(localX, ground - 0.08, localZ, scale, rotation, hash(seed, 7));
      if (hash(seed, 8) > 0.7 && ground < 24) broadleaves.push(tree);
      else pines.push(tree);
      trunks.push({ ...tree, tint: undefined });
      shadows.push({ ...add(localX, ground + 0.035, localZ, scale * 1.5, 0), sy: 1 });
    }

    for (let i = 0; i < 8; i += 1) {
      const seed = cx * 5003 + cz * 919 + i * 41;
      const localX = hash(seed, 21) * size;
      const localZ = hash(seed, 22) * size;
      const x = cx * size + localX;
      const z = cz * size + localZ;
      if (villageAt(x, z, 78) || onSettlementRoad(x, z, 3) || sceneryGroundClear(x, z, 2) || this.options.lakeAt(x, z) > 0.18) continue;
      const ground = this.options.heightAt(x, z);
      if (ground > 58) continue;
      const scale = 0.35 + hash(seed, 23) * 1.7;
      rocks.push({ ...add(localX, ground + scale * 0.18, localZ, scale, hash(seed, 25) * 6), sx: scale * 1.35, sy: scale * 0.65 });
      if (detail && i < 2) logs.push({ ...add(localX + 3, ground + 0.28, localZ + 2, 1, hash(seed, 24) * 6), sx: 0.85 + hash(seed, 26) * 0.8 });
    }

    if (detail) {
      for (let i = 0; i < 310; i += 1) {
        const seed = cx * 3571 + cz * 5471 + i * 23;
        const localX = hash(seed, 31) * size;
        const localZ = hash(seed, 32) * size;
        const x = cx * size + localX;
        const z = cz * size + localZ;
        if (Math.abs(x - this.options.trailAt(z)) < 4 + hash(seed, 33) * 2 || onSettlementRoad(x, z) || sceneryGroundClear(x, z, 1) || villageGroundClear(x, z) || this.options.lakeAt(x, z) > 0.3) continue;
        const ground = this.options.heightAt(x, z);
        if (ground > 48) continue;
        const scale = 0.7 + hash(seed, 34) * 1.15;
        grasses.push({ ...add(localX, ground - 0.04, localZ, scale, hash(seed, 35) * 6), sy: scale * (0.75 + hash(seed, 36) * 0.55) });
        if (i % 13 === 0 && !villageAt(x, z, 75)) bushes.push(add(localX, ground, localZ, 0.65 + hash(seed, 37) * 0.85, hash(seed, 38) * 6, hash(seed, 39)));
        if (i % 8 === 0) flowers.push(add(localX + 0.8, ground, localZ + 0.4, 0.7 + hash(seed, 43) * 0.7, hash(seed, 44) * 6));
        if (i % 25 === 0 && forestNear(x, z) > 0.45 && !villageAt(x, z, 75)) mushrooms.push(add(localX - 0.5, ground, localZ + 0.6, 0.8 + hash(seed, 45) * 0.7, 0));
      }
    }

    const addMesh = (geometry: THREE.BufferGeometry, material: THREE.Material, instances: Instance[], shadowsEnabled = false) => {
      const mesh = this.makeMesh(geometry, material, instances, shadowsEnabled);
      if (mesh) group.add(mesh);
    };
    addMesh(detail ? this.pine : this.pineLow, this.leavesMaterial, pines, true);
    addMesh(detail ? this.broadleaf : this.broadleafLow, this.leavesMaterial, broadleaves, true);
    addMesh(this.trunk, this.barkMaterial, trunks, true);
    addMesh(this.contact, this.groundShadowMaterial, shadows);
    addMesh(this.rock, this.rockMaterial, rocks, true);
    if (detail) {
      addMesh(this.grass, this.grassMaterial, grasses);
      addMesh(this.bush, this.leavesMaterial, bushes);
      addMesh(this.flower, this.flowerMaterial, flowers);
      addMesh(this.mushroom, this.flowerMaterial, mushrooms);
      addMesh(this.log, this.barkMaterial, logs, true);
    }
    this.options.scene.add(group);
    return { group, detail };
  }

  update(x: number, z: number) {
    const centerX = Math.floor(x / 100);
    const centerZ = Math.floor(z / 100);
    const centerKey = `${centerX},${centerZ}`;
    if (centerKey === this.centerKey) return;
    this.centerKey = centerKey;
    const wanted = new Set<string>();
    for (let cx = centerX - this.treeRadius; cx <= centerX + this.treeRadius; cx += 1) {
      for (let cz = centerZ - this.treeRadius; cz <= centerZ + this.treeRadius; cz += 1) {
        const key = `${cx},${cz}`;
        const detail = Math.abs(cx - centerX) <= this.detailRadius && Math.abs(cz - centerZ) <= this.detailRadius;
        wanted.add(key);
        const existing = this.chunks.get(key);
        if (existing && existing.detail !== detail) this.removeChunk(existing);
        if (!existing || existing.detail !== detail) this.chunks.set(key, this.createChunk(cx, cz, detail));
      }
    }
    for (const [key, chunk] of this.chunks) {
      if (!wanted.has(key)) {
        this.removeChunk(chunk);
        this.chunks.delete(key);
      }
    }
  }

  private removeChunk(chunk: VegetationChunk) {
    this.options.scene.remove(chunk.group);
    chunk.group.traverse((object) => { if (object instanceof THREE.InstancedMesh) object.dispose(); });
  }

  dispose() {
    this.chunks.forEach((chunk) => this.removeChunk(chunk));
    this.chunks.clear();
    [this.pine, this.pineLow, this.broadleaf, this.broadleafLow, this.trunk, this.grass, this.bush, this.flower, this.mushroom, this.rock, this.log, this.contact].forEach((geometry) => geometry.dispose());
    [this.leavesMaterial, this.grassMaterial, this.barkMaterial, this.rockMaterial, this.flowerMaterial, this.groundShadowMaterial].forEach((material) => material.dispose());
  }
}

function forestNear(x: number, z: number) {
  return noise(x * 0.008 + 4, z * 0.008 - 8);
}