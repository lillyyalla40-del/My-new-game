import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";

export type HousePlot = {
  x: number;
  z: number;
  rotation: number;
  width: number;
  depth: number;
  style: number;
  villageIndex: number;
  localX: number;
  localZ: number;
  kind: "home" | "workshop" | "barn" | "storehouse" | "hall";
};

export type Village = {
  name: string;
  x: number;
  z: number;
  rotation: number;
  houses: HousePlot[];
};

const DOOR_WIDTH = 2.3;
const WALL_THICKNESS = 0.22;
const PLAYER_RADIUS = 0.36;

const villageSites = [
  { name: "Oak Hollow", x: 16, z: 45, rotation: 0 },
  { name: "Willow Brook", x: -75, z: -145, rotation: -0.2 },
  { name: "Pine Haven", x: 175, z: 140, rotation: 0.3 },
];

const houseLayout = [
  { x: -14, z: 5, rotation: Math.PI / 2, width: 8.4, depth: 8.4 },
  { x: 14, z: 2, rotation: -Math.PI / 2, width: 9, depth: 8.2 },
  { x: -15, z: -16, rotation: Math.PI / 2, width: 8.6, depth: 8 },
  { x: 14, z: -18, rotation: -Math.PI / 2, width: 8.2, depth: 8.8 },
  { x: -14, z: 27, rotation: Math.PI / 2, width: 8.8, depth: 8.4 },
  { x: 14, z: 25, rotation: -Math.PI / 2, width: 9.4, depth: 9 },
  { x: -14, z: 47, rotation: Math.PI / 2, width: 8.2, depth: 8.2 },
  { x: 14, z: 45, rotation: -Math.PI / 2, width: 10.5, depth: 9.8 },
  { x: -14, z: -38, rotation: Math.PI / 2, width: 9.6, depth: 8.6 },
  { x: 14, z: -40, rotation: -Math.PI / 2, width: 8.4, depth: 8.4 },
  { x: -14, z: -58, rotation: Math.PI / 2, width: 9.2, depth: 8.6 },
  { x: 14, z: -60, rotation: -Math.PI / 2, width: 8.6, depth: 8.6 },
  ...[-58, -38, -17, 4, 26, 46].flatMap((z, index) => [
    { x: -34, z, rotation: Math.PI / 2, width: 8.4 + (index % 3) * 0.7, depth: 8.5 + (index % 2) * 0.8 },
    { x: 34, z: z + 1, rotation: -Math.PI / 2, width: 8.7 + (index % 2) * 1.1, depth: 8.4 + (index % 3) * 0.5 },
  ]),
];

export const VILLAGES: Village[] = villageSites.map((site, villageIndex) => {
  const cos = Math.cos(site.rotation);
  const sin = Math.sin(site.rotation);
  return {
    ...site,
    houses: houseLayout.map((plot, index) => {
      const scatter = index < 4 ? 0 : villageIndex === 1 ? 1.5 : villageIndex === 2 ? 0.8 : 0.4;
      const localX = plot.x + Math.sin(index * 4.7 + villageIndex) * scatter;
      const localZ = plot.z + Math.cos(index * 3.1 + villageIndex) * scatter;
      let kind: HousePlot["kind"] = "home";
      if (index === 0 || (villageIndex === 2 && index === 8)) kind = "workshop";
      if (index === 2 || index === 14 || (villageIndex === 1 && index % 5 === 0)) kind = "storehouse";
      if ((villageIndex === 1 && [6, 12, 18, 22].includes(index)) || (villageIndex === 0 && index === 20)) kind = "barn";
      if ((villageIndex === 0 && index === 7) || (villageIndex === 2 && index === 7)) kind = "hall";
      return {
        x: site.x + cos * localX + sin * localZ,
        z: site.z - sin * localX + cos * localZ,
        rotation: plot.rotation + site.rotation,
        width: plot.width + (kind === "hall" ? 1.1 : 0),
        depth: plot.depth + (kind === "barn" ? 0.9 : 0),
        style: villageIndex,
        villageIndex,
        localX,
        localZ,
        kind,
      };
    }),
  };
});

export const HOUSES = VILLAGES.flatMap((village) => village.houses);
const HOUSE_GRID_SIZE = 24;
const houseGrid = new Map<string, HousePlot[]>();
for (const house of HOUSES) {
  const extent = Math.hypot(house.width, house.depth) / 2 + 2;
  for (let x = Math.floor((house.x - extent) / HOUSE_GRID_SIZE); x <= Math.floor((house.x + extent) / HOUSE_GRID_SIZE); x += 1) {
    for (let z = Math.floor((house.z - extent) / HOUSE_GRID_SIZE); z <= Math.floor((house.z + extent) / HOUSE_GRID_SIZE); z += 1) {
      const key = `${x},${z}`;
      const bucket = houseGrid.get(key) ?? [];
      bucket.push(house);
      houseGrid.set(key, bucket);
    }
  }
}

function nearbyHouses(x: number, z: number) {
  return houseGrid.get(`${Math.floor(x / HOUSE_GRID_SIZE)},${Math.floor(z / HOUSE_GRID_SIZE)}`) ?? [];
}

function localPosition(house: HousePlot, x: number, z: number) {
  const dx = x - house.x;
  const dz = z - house.z;
  const cos = Math.cos(house.rotation);
  const sin = Math.sin(house.rotation);
  return { x: cos * dx - sin * dz, z: sin * dx + cos * dz };
}

export function villageAt(x: number, z: number, radius = 78) {
  return VILLAGES.find((village) => Math.hypot(x - village.x, z - village.z) < radius);
}

export function houseAt(x: number, z: number) {
  return nearbyHouses(x, z).find((house) => {
    const local = localPosition(house, x, z);
    return Math.abs(local.x) < house.width / 2 - 0.2 && Math.abs(local.z) < house.depth / 2 - 0.2;
  });
}

export function insideHouseFootprint(x: number, z: number, margin = 0) {
  return nearbyHouses(x, z).some((house) => {
    if (Math.abs(x - house.x) > 11 + margin || Math.abs(z - house.z) > 11 + margin) return false;
    const local = localPosition(house, x, z);
    return Math.abs(local.x) < house.width / 2 + margin && Math.abs(local.z) < house.depth / 2 + margin;
  });
}

export function villageGroundClear(x: number, z: number) {
  for (const village of VILLAGES) {
    const dx = x - village.x;
    const dz = z - village.z;
    if (Math.abs(dx) > 95 || Math.abs(dz) > 95) continue;
    const cos = Math.cos(village.rotation);
    const sin = Math.sin(village.rotation);
    const localX = cos * dx - sin * dz;
    const localZ = sin * dx + cos * dz;
    if ((Math.abs(localX) < 3.4 || Math.abs(Math.abs(localX) - 24) < 2.7) && Math.abs(localZ + 6) < 75) return true;
    if (Math.abs(localX) < 43 && (Math.abs(localZ - 36.5) < 1.8 || Math.abs(localZ + 49) < 1.8)) return true;
    if (Math.abs(localX) < 15.5 && (Math.abs(localZ - 3.5) < 1.8 || Math.abs(localZ + 17) < 1.8)) return true;
    if ((Math.abs(localX + 56) < 8.5 && Math.abs(localZ + 37) < 7.5) || (Math.abs(localX - 56) < 8.5 && Math.abs(localZ - 30) < 7.5)) return true;
    if (village.name === "Willow Brook" && Math.abs(localX + 56) < 8 && Math.abs(localZ - 17) < 7) return true;
    if (insideHouseFootprint(x, z, 0.8)) return true;
  }
  return false;
}

export function houseWallBlocks(x: number, z: number) {
  for (const house of nearbyHouses(x, z)) {
    if (Math.abs(x - house.x) > 11 || Math.abs(z - house.z) > 11) continue;
    const local = localPosition(house, x, z);
    const halfWidth = house.width / 2;
    const halfDepth = house.depth / 2;
    const wallRadius = WALL_THICKNESS / 2 + PLAYER_RADIUS;
    const withinWidth = Math.abs(local.x) < halfWidth + wallRadius;
    const withinDepth = Math.abs(local.z) < halfDepth + wallRadius;
    const sideWall = Math.abs(Math.abs(local.x) - halfWidth) < wallRadius && withinDepth;
    const backWall = Math.abs(local.z + halfDepth) < wallRadius && withinWidth;
    const frontWall = Math.abs(local.z - halfDepth) < wallRadius && withinWidth &&
      Math.abs(local.x) > DOOR_WIDTH / 2 - PLAYER_RADIUS;
    if (sideWall || backWall || frontWall) return true;
  }
  return false;
}

export function villageObstacleBlocks(x: number, z: number) {
  for (const village of VILLAGES) {
    const dx = x - village.x;
    const dz = z - village.z;
    if (Math.abs(dx) > 70 || Math.abs(dz) > 70) continue;
    const cos = Math.cos(village.rotation);
    const sin = Math.sin(village.rotation);
    const localX = cos * dx - sin * dz;
    const localZ = sin * dx + cos * dz;
    if (village.name === "Oak Hollow") {
      if (Math.hypot(localX + 6.8, localZ + 7) < 1.6 + PLAYER_RADIUS) return true;
      if (Math.abs(localX - 7) < 1.7 + PLAYER_RADIUS && Math.abs(localZ + 8) < 1.1 + PLAYER_RADIUS) return true;
      if (Math.abs(localX + 7) < 1.7 + PLAYER_RADIUS && Math.abs(localZ - 13) < 1.1 + PLAYER_RADIUS) return true;
    }
    if (village.name === "Willow Brook" && Math.hypot(localX + 55, localZ + 6) < 3 + PLAYER_RADIUS) return true;
    if (village.name === "Pine Haven" && Math.hypot(localX + 6.8, localZ + 8) < 2.8 + PLAYER_RADIUS) return true;
    if (Math.hypot(Math.abs(localX) - 7, localZ + 29) < 0.55 + PLAYER_RADIUS) return true;
  }
  return false;
}

type MaterialKey = "plaster0" | "plaster1" | "plaster2" | "roof0" | "roof1" | "roof2" |
  "wood" | "lightWood" | "timber" | "ceiling" | "stone" | "glass" | "linen" | "blanket" | "rug" | "path" |
  "soil" | "crop" | "foliage" | "canvas" | "metal" | "lamp" | "contact";

type Pieces = Record<MaterialKey, THREE.BufferGeometry[]>;

function makePieces(): Pieces {
  return {
    plaster0: [], plaster1: [], plaster2: [], roof0: [], roof1: [], roof2: [],
    wood: [], lightWood: [], timber: [], ceiling: [], stone: [], glass: [], linen: [], blanket: [], rug: [], path: [],
    soil: [], crop: [], foliage: [], canvas: [], metal: [], lamp: [], contact: [],
  };
}

function addCylinder(
  pieces: Pieces, key: MaterialKey, transform: THREE.Matrix4,
  top: number, bottom: number, height: number, x: number, y: number, z: number, sides = 10,
) {
  const geometry = new THREE.CylinderGeometry(top, bottom, height, sides, 1);
  geometry.translate(x, y, z);
  geometry.applyMatrix4(transform);
  pieces[key].push(geometry);
}

function addBox(
  pieces: Pieces,
  key: MaterialKey,
  transform: THREE.Matrix4,
  width: number,
  height: number,
  depth: number,
  x: number,
  y: number,
  z: number,
  angle = 0,
) {
  const geometry = new THREE.BoxGeometry(width, height, depth);
  if (angle) geometry.rotateZ(angle);
  geometry.translate(x, y, z);
  geometry.applyMatrix4(transform);
  pieces[key].push(geometry);
}

function addGable(pieces: Pieces, key: MaterialKey, transform: THREE.Matrix4, width: number, rise: number, y: number, z: number) {
  const geometry = new THREE.CylinderGeometry(1, 1, WALL_THICKNESS, 3, 1);
  geometry.rotateX(-Math.PI / 2);
  geometry.scale(width / Math.sqrt(3), rise / 1.5, 1);
  geometry.translate(0, y + rise / 3, z);
  geometry.applyMatrix4(transform);
  pieces[key].push(geometry);
}

function addHouse(pieces: Pieces, house: HousePlot, ground: number) {
  const transform = new THREE.Matrix4().compose(
    new THREE.Vector3(house.x, ground, house.z),
    new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), house.rotation),
    new THREE.Vector3(1, 1, 1),
  );
  const plaster = house.kind === "barn" || house.kind === "storehouse" ? "timber" : `plaster${house.style}` as MaterialKey;
  const roof = `roof${house.style}` as MaterialKey;
  const width = house.width;
  const depth = house.depth;
  const halfWidth = width / 2;
  const halfDepth = depth / 2;
  const wallHeight = house.kind === "hall" ? 5.15 : house.kind === "barn" ? 4.75 : 4.05 + (house.width % 1) * 0.35;
  const doorHeight = 2.85;
  const roofRise = house.kind === "hall" ? 3.1 : house.kind === "barn" ? 2.7 : 2.05 + (house.depth % 1) * 0.7;

  const box = (key: MaterialKey, w: number, h: number, d: number, x: number, y: number, z: number, angle = 0) =>
    addBox(pieces, key, transform, w, h, d, x, y, z, angle);

  box("contact", width + 1.1, 0.025, depth + 1.1, 0, 0.012, 0);
  box("stone", width + 0.22, 0.32, depth + 0.22, 0, -0.08, 0);
  box("lightWood", width - 0.18, 0.12, depth - 0.18, 0, 0.11, 0);
  for (let i = 1; i < 8; i += 1) {
    box("wood", 0.025, 0.012, depth - 0.24, -halfWidth + (i * width) / 8, 0.177, 0);
  }

  const rearWindowWidth = 2;
  const rearWindowHeight = 1.45;
  const rearWindowBottom = 1.35;
  const rearSideWidth = (width - rearWindowWidth) / 2;
  box(plaster, rearSideWidth, wallHeight, WALL_THICKNESS, -(rearWindowWidth / 2 + rearSideWidth / 2), wallHeight / 2, -halfDepth);
  box(plaster, rearSideWidth, wallHeight, WALL_THICKNESS, rearWindowWidth / 2 + rearSideWidth / 2, wallHeight / 2, -halfDepth);
  box(plaster, rearWindowWidth, rearWindowBottom, WALL_THICKNESS, 0, rearWindowBottom / 2, -halfDepth);
  box(plaster, rearWindowWidth, wallHeight - rearWindowBottom - rearWindowHeight, WALL_THICKNESS, 0, rearWindowBottom + rearWindowHeight + (wallHeight - rearWindowBottom - rearWindowHeight) / 2, -halfDepth);
  box("glass", rearWindowWidth, rearWindowHeight, 0.035, 0, rearWindowBottom + rearWindowHeight / 2, -halfDepth);
  for (const frameZ of [-halfDepth - 0.13, -halfDepth + 0.13]) {
    box("wood", 0.1, rearWindowHeight + 0.2, 0.12, -rearWindowWidth / 2, rearWindowBottom + rearWindowHeight / 2, frameZ);
    box("wood", 0.1, rearWindowHeight + 0.2, 0.12, rearWindowWidth / 2, rearWindowBottom + rearWindowHeight / 2, frameZ);
    box("wood", rearWindowWidth + 0.18, 0.1, 0.12, 0, rearWindowBottom, frameZ);
    box("wood", rearWindowWidth + 0.18, 0.1, 0.12, 0, rearWindowBottom + rearWindowHeight, frameZ);
    box("wood", 0.07, rearWindowHeight, 0.12, 0, rearWindowBottom + rearWindowHeight / 2, frameZ);
    box("wood", rearWindowWidth, 0.07, 0.12, 0, rearWindowBottom + rearWindowHeight / 2, frameZ);
  }
  const frontSideWidth = (width - DOOR_WIDTH) / 2;
  box(plaster, frontSideWidth, wallHeight, WALL_THICKNESS, -(DOOR_WIDTH / 2 + frontSideWidth / 2), wallHeight / 2, halfDepth);
  box(plaster, frontSideWidth, wallHeight, WALL_THICKNESS, DOOR_WIDTH / 2 + frontSideWidth / 2, wallHeight / 2, halfDepth);
  box(plaster, DOOR_WIDTH, wallHeight - doorHeight, WALL_THICKNESS, 0, doorHeight + (wallHeight - doorHeight) / 2, halfDepth);
  for (const x of [-halfWidth, halfWidth]) {
    for (const z of [-halfDepth, halfDepth]) box("wood", 0.18, wallHeight, 0.18, x, wallHeight / 2, z);
  }
  box("wood", width, 0.14, 0.2, 0, wallHeight - 0.1, halfDepth + 0.08);
  box("wood", width, 0.14, 0.2, 0, wallHeight - 0.1, -halfDepth - 0.08);

  const windowCenter = -0.8;
  const windowWidth = 1.7;
  const windowBottom = 1.3;
  const windowHeight = 1.45;
  for (const side of [-1, 1]) {
    const x = side * halfWidth;
    const rearLength = windowCenter - windowWidth / 2 + halfDepth;
    const frontLength = halfDepth - windowCenter - windowWidth / 2;
    box(plaster, WALL_THICKNESS, wallHeight, rearLength, x, wallHeight / 2, -halfDepth + rearLength / 2);
    box(plaster, WALL_THICKNESS, wallHeight, frontLength, x, wallHeight / 2, windowCenter + windowWidth / 2 + frontLength / 2);
    box(plaster, WALL_THICKNESS, windowBottom, windowWidth, x, windowBottom / 2, windowCenter);
    box(plaster, WALL_THICKNESS, wallHeight - windowBottom - windowHeight, windowWidth, x, windowBottom + windowHeight + (wallHeight - windowBottom - windowHeight) / 2, windowCenter);
    box("glass", 0.035, windowHeight, windowWidth, x, windowBottom + windowHeight / 2, windowCenter);
    const frameX = x + side * 0.13;
    box("wood", 0.12, windowHeight + 0.2, 0.1, frameX, windowBottom + windowHeight / 2, windowCenter - windowWidth / 2);
    box("wood", 0.12, windowHeight + 0.2, 0.1, frameX, windowBottom + windowHeight / 2, windowCenter + windowWidth / 2);
    box("wood", 0.12, 0.1, windowWidth + 0.16, frameX, windowBottom, windowCenter);
    box("wood", 0.12, 0.1, windowWidth + 0.16, frameX, windowBottom + windowHeight, windowCenter);
    box("wood", 0.12, windowHeight, 0.07, frameX, windowBottom + windowHeight / 2, windowCenter);
    box("wood", 0.12, 0.07, windowWidth, frameX, windowBottom + windowHeight / 2, windowCenter);
    box("lightWood", 0.34, 0.1, windowWidth + 0.35, x + side * 0.18, windowBottom - 0.06, windowCenter);
    if (house.kind === "home" || house.kind === "hall") {
      box("lightWood", 0.5, 0.32, windowWidth + 0.35, x + side * 0.35, 1.02, windowCenter);
      for (let plant = -2; plant <= 2; plant += 1) {
        addCylinder(pieces, "crop", transform, 0.02, 0.12, 0.4, x + side * 0.35, 1.34, windowCenter + plant * 0.32, 5);
        addCylinder(pieces, "linen", transform, 0.1, 0.12, 0.06, x + side * 0.35, 1.56, windowCenter + plant * 0.32, 6);
      }
    }
  }

  box("wood", 0.19, doorHeight + 0.15, 0.3, -DOOR_WIDTH / 2, doorHeight / 2, halfDepth + 0.07);
  box("wood", 0.19, doorHeight + 0.15, 0.3, DOOR_WIDTH / 2, doorHeight / 2, halfDepth + 0.07);
  box("wood", DOOR_WIDTH + 0.3, 0.2, 0.3, 0, doorHeight, halfDepth + 0.07);
  // The door is already swung outward, leaving the whole doorway open.
  box("lightWood", 0.14, 2.58, DOOR_WIDTH - 0.18, -DOOR_WIDTH / 2 - 0.09, 1.32, halfDepth + DOOR_WIDTH / 2);
  box("wood", 0.18, 0.12, DOOR_WIDTH - 0.28, -DOOR_WIDTH / 2 - 0.1, 0.55, halfDepth + DOOR_WIDTH / 2);
  box("wood", 0.18, 0.12, DOOR_WIDTH - 0.28, -DOOR_WIDTH / 2 - 0.1, 2.1, halfDepth + DOOR_WIDTH / 2);
  box("stone", 2.7, 0.14, 1.05, 0, 0.04, halfDepth + 0.5);
  if (house.kind === "workshop" || house.kind === "hall") {
    for (const x of [-1.75, 1.75]) box("wood", 0.14, 2.95, 0.14, x, 1.48, halfDepth + 1.05);
    box(house.kind === "workshop" ? "canvas" : roof, 3.85, 0.14, 1.55, 0, 3.05, halfDepth + 0.78);
  }

  for (const side of [-1, 1]) {
    const windowX = side * (DOOR_WIDTH / 2 + frontSideWidth / 2);
    box("wood", 1.35, 1.45, 0.12, windowX, 2.15, halfDepth + 0.15);
    box("glass", 1.14, 1.23, 0.13, windowX, 2.15, halfDepth + 0.23);
    box("wood", 0.07, 1.25, 0.15, windowX, 2.15, halfDepth + 0.3);
    box("wood", 1.17, 0.07, 0.15, windowX, 2.15, halfDepth + 0.3);
  }

  addGable(pieces, plaster, transform, width, roofRise, wallHeight, -halfDepth);
  addGable(pieces, plaster, transform, width, roofRise, wallHeight, halfDepth);
  const overhang = halfWidth + 0.55;
  const slopeRise = roofRise * overhang / halfWidth;
  const slopeLength = Math.hypot(overhang, slopeRise);
  const angle = Math.atan2(slopeRise, overhang);
  for (const side of [-1, 1]) {
    const roofAngle = -side * angle;
    const roofX = side * overhang / 2;
    const roofY = wallHeight + roofRise - slopeRise / 2;
    box(roof, slopeLength, 0.26, depth + 1.1, roofX, roofY, 0, roofAngle);
    for (let i = 0; i < 7; i += 1) {
      const z = -halfDepth + (i * depth) / 6;
      box("wood", slopeLength - 0.08, 0.025, 0.045, roofX - Math.sin(roofAngle) * 0.145, roofY + Math.cos(roofAngle) * 0.145, z, roofAngle);
    }
    box("wood", 0.18, 0.2, depth + 1.2, side * overhang, wallHeight + roofRise - slopeRise, 0);
  }
  box("stone", 0.8, 2.1, 0.85, -width * 0.27, wallHeight + 1.35, -depth * 0.27);
  box("wood", 0.98, 0.14, 1, -width * 0.27, wallHeight + 2.4, -depth * 0.27);
  box("ceiling", width - 0.2, 0.12, depth - 0.2, 0, wallHeight - 0.12, 0);
  for (const x of [-width * 0.28, 0, width * 0.28]) box("wood", 0.14, 0.14, depth - 0.24, x, wallHeight - 0.24, 0);

  // Keep the center of each room clear so the open doorway leads inside.
  box("rug", 2.15, 0.035, 2.6, 0, 0.19, 0.25);
  if (house.kind === "home" || house.kind === "hall") {
    box("wood", 1.85, 0.35, 2.75, -halfWidth + 1.25, 0.38, -halfDepth + 1.8);
    box("linen", 1.75, 0.22, 2.65, -halfWidth + 1.25, 0.67, -halfDepth + 1.8);
    box("blanket", 1.77, 0.1, 1.55, -halfWidth + 1.25, 0.83, -halfDepth + 2.28);
    box("linen", 1.15, 0.2, 0.58, -halfWidth + 1.25, 0.86, -halfDepth + 0.82);
  } else {
    box("lightWood", 1.1, 1.05, 1.05, -halfWidth + 1, 0.7, -halfDepth + 1.1);
    box("wood", 0.95, 0.85, 0.95, -halfWidth + 1.75, 0.6, -halfDepth + 2.1);
    addCylinder(pieces, "lightWood", transform, 0.48, 0.53, 0.95, -halfWidth + 1, 0.66, -halfDepth + 3.3);
    if (house.kind === "workshop") {
      box("stone", 1.25, 1.1, 1.25, -halfWidth + 1.15, 0.72, -halfDepth + 1.2);
      box("metal", 0.9, 0.12, 0.9, -halfWidth + 1.15, 1.3, -halfDepth + 1.2);
    }
  }
  box("lightWood", 1.7, 0.16, 1.15, halfWidth - 1.4, 1.15, -halfDepth + 1.5);
  for (const dx of [-0.64, 0.64]) {
    for (const dz of [-0.42, 0.42]) {
      box("wood", 0.12, 1.02, 0.12, halfWidth - 1.4 + dx, 0.57, -halfDepth + 1.5 + dz);
    }
  }
  if (Math.round(Math.abs(house.localZ)) % 3 !== 0) {
    addCylinder(pieces, "lightWood", transform, 0.42, 0.46, 0.9, halfWidth + 0.75, 0.48, -halfDepth + 1.1);
    addCylinder(pieces, "metal", transform, 0.47, 0.47, 0.07, halfWidth + 0.75, 0.3, -halfDepth + 1.1);
    addCylinder(pieces, "metal", transform, 0.43, 0.43, 0.07, halfWidth + 0.75, 0.72, -halfDepth + 1.1);
  }
}

function addHouseLow(pieces: Pieces, house: HousePlot, ground: number) {
  const transform = new THREE.Matrix4().compose(
    new THREE.Vector3(house.x, ground, house.z),
    new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), house.rotation),
    new THREE.Vector3(1, 1, 1),
  );
  const wall = house.kind === "barn" || house.kind === "storehouse" ? "timber" : `plaster${house.style}` as MaterialKey;
  const roof = `roof${house.style}` as MaterialKey;
  const h = house.kind === "hall" ? 5.15 : house.kind === "barn" ? 4.75 : 4.2;
  const rise = house.kind === "hall" ? 3.1 : 2.4;
  const halfW = house.width / 2;
  const halfD = house.depth / 2;
  const box = (key: MaterialKey, w: number, height: number, d: number, x: number, y: number, z: number, angle = 0) =>
    addBox(pieces, key, transform, w, height, d, x, y, z, angle);
  box(wall, house.width, h, WALL_THICKNESS, 0, h / 2, -halfD);
  box(wall, WALL_THICKNESS, h, house.depth, -halfW, h / 2, 0);
  box(wall, WALL_THICKNESS, h, house.depth, halfW, h / 2, 0);
  const side = (house.width - DOOR_WIDTH) / 2;
  box(wall, side, h, WALL_THICKNESS, -(DOOR_WIDTH + side) / 2, h / 2, halfD);
  box(wall, side, h, WALL_THICKNESS, (DOOR_WIDTH + side) / 2, h / 2, halfD);
  box(wall, DOOR_WIDTH, h - 2.85, WALL_THICKNESS, 0, (h + 2.85) / 2, halfD);
  addGable(pieces, wall, transform, house.width, rise, h, -halfD);
  addGable(pieces, wall, transform, house.width, rise, h, halfD);
  const span = halfW + 0.55;
  const slopeRise = rise * span / halfW;
  const length = Math.hypot(span, slopeRise);
  const angle = Math.atan2(slopeRise, span);
  for (const sideSign of [-1, 1]) {
    box(roof, length, 0.24, house.depth + 1, sideSign * span / 2, h + rise - slopeRise / 2, 0, -sideSign * angle);
  }
  box("stone", 0.7, 1.8, 0.7, -house.width * 0.27, h + 1.3, -house.depth * 0.27);
}

function addVillageDetails(pieces: Pieces, village: Village, transform: THREE.Matrix4, simple: boolean) {
  const box = (key: MaterialKey, w: number, h: number, d: number, x: number, y: number, z: number, angle = 0) =>
    addBox(pieces, key, transform, w, h, d, x, y, z, angle);
  const cylinder = (key: MaterialKey, top: number, bottom: number, h: number, x: number, y: number, z: number, sides = 10) =>
    addCylinder(pieces, key, transform, top, bottom, h, x, y, z, sides);

  for (const x of [-24, 0, 24]) box("path", x === 0 ? 5.4 : 4.3, 0.07, 150, x, 0.025, -6);
  for (const z of [-49, 36.5]) box("path", 86, 0.07, 3.3, 0, 0.026, z);
  for (const z of [3.5, -17]) box("path", 30, 0.07, 2.7, 0, 0.027, z);
  box("path", 16, 0.075, 16, 0, 0.029, -7);

  if (village.name === "Willow Brook") {
    cylinder("stone", 2.1, 3.0, 10, -55, 5, -6, 12);
    cylinder("roof1", 0, 2.6, 2.5, -55, 11.25, -6, 12);
    box("wood", 0.18, 2.5, 1.35, -52.3, 1.3, -6);
  } else if (village.name === "Pine Haven") {
    cylinder("stone", 2.25, 2.8, 11, -6.8, 5.5, -8, 12);
    cylinder("roof2", 0, 2.65, 2.5, -6.8, 12.25, -8, 12);
    box("wood", 1.1, 1.5, 0.16, -6.8, 7.5, -5.68);
    box("lightWood", 0.15, 1.3, 0.18, -6.8, 7.5, -5.58);
  } else {
    cylinder("stone", 1.4, 1.55, 1.05, -6.8, 0.53, -7, 12);
    cylinder("metal", 1.15, 1.15, 0.06, -6.8, 1.07, -7, 12);
    for (const x of [-8.0, -5.6]) box("wood", 0.16, 2.5, 0.16, x, 2.15, -7);
    box("wood", 2.75, 0.17, 0.17, -6.8, 3.35, -7);
    box("roof0", 1.65, 0.14, 2, -7.52, 3.66, -7, 0.38);
    box("roof0", 1.65, 0.14, 2, -6.08, 3.66, -7, -0.38);
  }
  if (simple) return;

  for (const x of [-7, 7]) {
    cylinder("wood", 0.25, 0.38, 5.2, x, 2.6, -29, 8);
    for (const [dx, dy, dz, radius] of [[0, 5.8, 0, 2.2], [-1.2, 5.6, 0.1, 1.5], [1.1, 5.9, -0.1, 1.6], [0, 7, 0, 1.5]]) {
      const crown = new THREE.SphereGeometry(radius, 8, 6);
      crown.scale(1, 0.72, 1);
      crown.translate(x + dx, dy, -29 + dz);
      crown.applyMatrix4(transform);
      pieces.foliage.push(crown);
    }
  }

  for (const x of [-5.6, 5.6]) {
    for (const z of [-55, -29, 0, 32, 55]) {
      box("wood", 0.17, 3.1, 0.17, x, 1.55, z);
      box("metal", 0.48, 0.56, 0.48, x, 3.18, z);
      box("lamp", 0.31, 0.34, 0.31, x, 3.19, z);
      box("roof0", 0.58, 0.11, 0.58, x, 3.52, z);
    }
  }

  if (village.name === "Oak Hollow") {
    for (const [x, z] of [[7, -8], [-7, 13]]) {
      for (const dx of [-1.5, 1.5]) for (const dz of [-0.8, 0.8]) box("wood", 0.12, 2.35, 0.12, x + dx, 1.18, z + dz);
      box("lightWood", 3.1, 0.16, 1.7, x, 1.05, z);
      box("canvas", 3.6, 0.12, 2.2, x, 2.45, z);
      box("wood", 0.9, 0.55, 0.8, x - 0.7, 1.4, z);
      cylinder("lightWood", 0.35, 0.4, 0.7, x + 0.8, 1.45, z, 8);
    }
  }

  for (const side of [-1, 1]) {
    const x = side * 56;
    const z = side === -1 ? -37 : 30;
    box("soil", 15, 0.08, 13, x, 0.045, z);
    for (let row = -2; row <= 2; row += 1) {
      box("lightWood", 0.16, 0.1, 12, x + row * 2.6, 0.12, z);
      for (let plant = -4; plant <= 4; plant += 1) {
        cylinder("crop", 0.02, 0.3, 0.55 + ((plant + row + 12) % 3) * 0.1, x + row * 2.6, 0.4, z + plant * 1.25, 5);
      }
    }
  }

  if (village.name === "Willow Brook") {
    const x = -56;
    const z = 17;
    for (let i = -2; i <= 2; i += 1) {
      for (const side of [-1, 1]) box("wood", 0.14, 1.25, 0.14, x + i * 3.5, 0.63, z + side * 6);
    }
    for (const side of [-1, 1]) {
      box("lightWood", 14.2, 0.12, 0.12, x, 0.86, z + side * 6);
      box("lightWood", 14.2, 0.12, 0.12, x, 0.42, z + side * 6);
      for (const dz of [-3, 3]) box("wood", 0.14, 1.25, 0.14, x + side * 7, 0.63, z + dz);
      box("lightWood", 0.12, 0.12, 5.8, x + side * 7, 0.86, z - 3);
      box("lightWood", 0.12, 0.12, 5.8, x + side * 7, 0.42, z - 3);
    }
  }

  for (const [x, z] of [[-8.3, 21], [8.3, -33]]) {
    box("lightWood", 2.1, 0.16, 0.65, x, 0.75, z);
    for (const dx of [-0.75, 0.75]) box("wood", 0.14, 0.7, 0.55, x + dx, 0.35, z);
    box("wood", 2.1, 0.13, 0.12, x, 1.35, z - 0.25);
  }
  for (const x of [-47, 47]) {
    box("wood", 2.6, 0.2, 1.6, x, 0.8, 11);
    box("lightWood", 2.4, 0.75, 0.12, x, 1.22, 10.25);
    box("lightWood", 2.4, 0.75, 0.12, x, 1.22, 11.75);
    for (const dz of [-0.95, 0.95]) {
      for (const dx of [-0.75, 0.75]) {
        const wheel = new THREE.CylinderGeometry(0.58, 0.58, 0.18, 12);
        wheel.rotateX(Math.PI / 2);
        wheel.translate(x + dx, 0.55, 11 + dz);
        wheel.applyMatrix4(transform);
        pieces.wood.push(wheel);
      }
    }
  }
}

export function createVillageMeshes(heightAt: (x: number, z: number) => number, dirtTexture: THREE.Texture) {
  const group = new THREE.Group();
  group.name = "villages";
  const loader = new THREE.TextureLoader();
  const texture = (path: string, repeat: number) => {
    const map = loader.load(path);
    map.colorSpace = THREE.SRGBColorSpace;
    map.wrapS = map.wrapT = THREE.RepeatWrapping;
    map.repeat.set(repeat, repeat);
    map.anisotropy = 4;
    return map;
  };
  const woodMap = texture("/textures/wood.jpg", 1.3);
  const stoneMap = texture("/textures/stone.jpg", 1.4);
  const roofMap = texture("/textures/roof.jpg", 1.8);
  const materials: Record<MaterialKey, THREE.MeshStandardMaterial> = {
    plaster0: new THREE.MeshStandardMaterial({ color: "#e5d5b9", map: stoneMap, roughness: 0.98, bumpMap: stoneMap, bumpScale: 0.035 }),
    plaster1: new THREE.MeshStandardMaterial({ color: "#d4c9ae", map: stoneMap, roughness: 0.98, bumpMap: stoneMap, bumpScale: 0.035 }),
    plaster2: new THREE.MeshStandardMaterial({ color: "#d4d7c9", map: stoneMap, roughness: 0.98, bumpMap: stoneMap, bumpScale: 0.035 }),
    roof0: new THREE.MeshStandardMaterial({ color: "#cbb7a4", map: roofMap, roughness: 0.95 }),
    roof1: new THREE.MeshStandardMaterial({ color: "#dac19e", map: roofMap, roughness: 0.96 }),
    roof2: new THREE.MeshStandardMaterial({ color: "#b8c8c5", map: roofMap, roughness: 0.94 }),
    wood: new THREE.MeshStandardMaterial({ color: "#b5a28f", map: woodMap, roughness: 0.94 }),
    lightWood: new THREE.MeshStandardMaterial({ color: "#e4cbae", map: woodMap, roughness: 0.92 }),
    timber: new THREE.MeshStandardMaterial({ color: "#c9b397", map: woodMap, roughness: 0.95, bumpMap: woodMap, bumpScale: 0.025 }),
    ceiling: new THREE.MeshStandardMaterial({ color: "#c5b495", map: woodMap, roughness: 0.95, emissive: "#4c3e2c", emissiveIntensity: 0.45 }),
    stone: new THREE.MeshStandardMaterial({ color: "#b5b7a9", map: stoneMap, roughness: 1, bumpMap: stoneMap, bumpScale: 0.04 }),
    glass: new THREE.MeshStandardMaterial({ color: "#a5c7bd", transparent: true, opacity: 0.42, depthWrite: false, roughness: 0.25, metalness: 0.05 }),
    linen: new THREE.MeshStandardMaterial({ color: "#e3dbc3", roughness: 1 }),
    blanket: new THREE.MeshStandardMaterial({ color: "#9b796b", roughness: 1 }),
    rug: new THREE.MeshStandardMaterial({ color: "#a58c75", roughness: 1 }),
    path: new THREE.MeshStandardMaterial({ color: "#c0ad8b", map: dirtTexture, roughness: 1 }),
    soil: new THREE.MeshStandardMaterial({ color: "#776146", roughness: 1 }),
    crop: new THREE.MeshStandardMaterial({ color: "#758c50", roughness: 1 }),
    foliage: new THREE.MeshStandardMaterial({ color: "#6b885a", roughness: 1, flatShading: true }),
    canvas: new THREE.MeshStandardMaterial({ color: "#d1b893", roughness: 1, side: THREE.DoubleSide }),
    metal: new THREE.MeshStandardMaterial({ color: "#625e4d", roughness: 0.75, metalness: 0.3 }),
    lamp: new THREE.MeshStandardMaterial({ color: "#e4c78d", emissive: "#d4964f", emissiveIntensity: 0.8, roughness: 0.8 }),
    contact: new THREE.MeshStandardMaterial({ color: "#394a38", transparent: true, opacity: 0.22, depthWrite: false, roughness: 1 }),
  };
  const resources: Array<THREE.BufferGeometry | THREE.Material | THREE.Texture> = [...Object.values(materials), woodMap, stoneMap, roofMap];
  const rotors: THREE.Group[] = [];

  VILLAGES.forEach((village) => {
    const ground = heightAt(village.x, village.z);
    const transform = new THREE.Matrix4().compose(
      new THREE.Vector3(village.x, ground, village.z),
      new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), village.rotation),
      new THREE.Vector3(1, 1, 1),
    );
    const buildLevel = (simple: boolean, houses: HousePlot[], includeDetails: boolean, originX: number, originZ: number) => {
      const pieces = makePieces();
      if (includeDetails) addVillageDetails(pieces, village, transform, simple);
      houses.forEach((house) => simple ? addHouseLow(pieces, house, ground) : addHouse(pieces, house, ground));
      const level = new THREE.Group();
      for (const key of Object.keys(pieces) as MaterialKey[]) {
        if (!pieces[key].length) continue;
        const geometry = mergeGeometries(pieces[key]);
        pieces[key].forEach((piece) => piece.dispose());
        if (!geometry) throw new Error(`Could not build village geometry: ${key}`);
        geometry.translate(-originX, -ground, -originZ);
        const mesh = new THREE.Mesh(geometry, materials[key]);
        mesh.castShadow = !["glass", "path", "soil", "crop", "rug", "lamp", "contact"].includes(key);
        mesh.receiveShadow = key !== "glass" && key !== "lamp" && key !== "contact";
        level.add(mesh);
        resources.push(geometry);
      }
      return level;
    };
    const detailsLod = new THREE.LOD();
    detailsLod.position.set(village.x, ground, village.z);
    detailsLod.addLevel(buildLevel(false, [], true, village.x, village.z), 0);
    detailsLod.addLevel(buildLevel(true, [], true, village.x, village.z), 140, 0.1);
    group.add(detailsLod);
    for (const [minimum, maximum, centerZ] of [[-100, -26, -49], [-26, 15, -6], [15, 100, 36]]) {
      const houses = village.houses.filter((house) => house.localZ >= minimum && house.localZ < maximum);
      const originX = village.x + Math.sin(village.rotation) * centerZ;
      const originZ = village.z + Math.cos(village.rotation) * centerZ;
      const lod = new THREE.LOD();
      lod.position.set(originX, ground, originZ);
      lod.addLevel(buildLevel(false, houses, false, originX, originZ), 0);
      lod.addLevel(buildLevel(true, houses, false, originX, originZ), 52, 0.08);
      group.add(lod);
    }

    if (village.name === "Willow Brook") {
      const mount = new THREE.Group();
      mount.position.set(village.x, ground, village.z);
      mount.rotation.y = village.rotation;
      const rotor = new THREE.Group();
      rotor.position.set(-52.1, 7.3, -6);
      const blade = new THREE.BoxGeometry(0.18, 3.3, 0.62);
      blade.translate(0, 1.65, 0);
      for (let i = 0; i < 4; i += 1) {
        const vane = new THREE.Mesh(blade, materials.lightWood);
        vane.rotation.x = i * Math.PI / 2;
        vane.castShadow = true;
        rotor.add(vane);
      }
      mount.add(rotor);
      group.add(mount);
      resources.push(blade);
      rotors.push(rotor);
    }
  });

  return { group, resources, rotors, textures: { wood: woodMap, stone: stoneMap } };
}