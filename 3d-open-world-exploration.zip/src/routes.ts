import * as THREE from "three";

const controls = [
  [[16, -36], [2, -44], [-42, -53], [-70, -60], [-89, -77]],
  [[16, 114], [49, 126], [77, 149], [110, 170], [145, 188]],
];

const curves = controls.map((points) => new THREE.CatmullRomCurve3(
  points.map(([x, z]) => new THREE.Vector3(x, 0, z)), false, "catmullrom", 0.35,
));

export const ROAD_SAMPLES = curves.map((curve) => curve.getSpacedPoints(110).map((point) => ({ x: point.x, z: point.z })));
const ROAD_GRID_SIZE = 20;
const roadGrid = new Map<string, Array<{ x: number; z: number }>>();
for (const point of ROAD_SAMPLES.flat()) {
  const key = `${Math.floor(point.x / ROAD_GRID_SIZE)},${Math.floor(point.z / ROAD_GRID_SIZE)}`;
  const bucket = roadGrid.get(key) ?? [];
  bucket.push(point);
  roadGrid.set(key, bucket);
}

export function onSettlementRoad(x: number, z: number, margin = 0) {
  const radius = 4.2 + margin;
  const radiusSq = radius * radius;
  const cellX = Math.floor(x / ROAD_GRID_SIZE);
  const cellZ = Math.floor(z / ROAD_GRID_SIZE);
  for (let gx = cellX - 1; gx <= cellX + 1; gx += 1) {
    for (let gz = cellZ - 1; gz <= cellZ + 1; gz += 1) {
      const points = roadGrid.get(`${gx},${gz}`);
      if (!points) continue;
      for (const point of points) {
        const dx = x - point.x;
        const dz = z - point.z;
        if (Math.abs(dx) < radius && Math.abs(dz) < radius && dx * dx + dz * dz < radiusSq) return true;
      }
    }
  }
  return false;
}

export function createSettlementRoads(heightAt: (x: number, z: number) => number, dirt: THREE.Texture) {
  const group = new THREE.Group();
  group.name = "settlement-roads";
  const resources: Array<THREE.BufferGeometry | THREE.Material> = [];
  const material = new THREE.MeshStandardMaterial({
    map: dirt,
    vertexColors: true,
    roughness: 1,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -1,
    side: THREE.DoubleSide,
  });
  resources.push(material);
  for (const curve of curves) {
    const positions: number[] = [];
    const colors: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];
    const count = 180;
    const color = new THREE.Color("#c6b48c");
    for (let i = 0; i <= count; i += 1) {
      const t = i / count;
      const point = curve.getPointAt(t);
      const tangent = curve.getTangentAt(t).normalize();
      const normalX = -tangent.z;
      const normalZ = tangent.x;
      const width = 3.1 + Math.sin(t * 19) * 0.25;
      const offsets = [-width - 1.5, -width, width, width + 1.5];
      offsets.forEach((offset, edge) => {
        const x = point.x + normalX * offset;
        const z = point.z + normalZ * offset;
        positions.push(x, heightAt(x, z) + 0.16, z);
        colors.push(color.r, color.g, color.b, edge === 0 || edge === 3 ? 0 : 0.88);
        uvs.push(edge / 3, t * 2.8);
      });
      if (i < count) {
        for (let edge = 0; edge < 3; edge += 1) {
          const a = i * 4 + edge;
          indices.push(a, a + 4, a + 1, a + 1, a + 4, a + 5);
        }
      }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 4));
    geometry.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();
    const mesh = new THREE.Mesh(geometry, material);
    mesh.receiveShadow = true;
    group.add(mesh);
    resources.push(geometry);
  }
  return { group, resources };
}