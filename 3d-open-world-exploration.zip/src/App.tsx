import { useCallback, useEffect, useRef, useState } from "react";
import type { PointerEvent as ReactPointerEvent } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  ChevronRight,
  Compass,
  Expand,
  LocateFixed,
  Map as MapIcon,
  MapPin,
  Minimize,
  Moon,
  Mouse,
  MoveUpRight,
  RotateCcw,
  Sun,
  X,
} from "lucide-react";
import { lakeAmount, START_POSITION, terrainHeight, trailX, WanderWorld } from "./world";
import type { GraphicsQuality, WorldPosition } from "./world";
import { houseAt, VILLAGES, villageAt } from "./villages";
import { ROAD_SAMPLES } from "./routes";
import { BRIDGE_MAP, LANDMARKS } from "./scenery";

type Panel = "map" | "controls" | null;

function MountainMark() {
  return (
    <svg className="mountain-mark" viewBox="0 0 42 42" fill="none" aria-hidden="true">
      <circle cx="21" cy="21" r="19.25" stroke="currentColor" strokeWidth="1.2" />
      <path d="M7.5 27.5 16.8 14l5.2 7 3.1-4 9.4 10.5H7.5Z" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" />
      <path d="m13.7 18.6 3.1 2.1 2.4-1.4M23.5 19.1l1.7 1.4 1.6-.9" stroke="currentColor" strokeWidth="1" strokeLinejoin="round" />
      <circle cx="26.7" cy="12.6" r="2" stroke="currentColor" strokeWidth="1" />
    </svg>
  );
}

function direction(bearing: number) {
  return ["N", "NE", "E", "SE", "S", "SW", "W", "NW"][Math.round(bearing / 45) % 8];
}

function locationName(position: WorldPosition) {
  const village = villageAt(position.x, position.z);
  if (village) return village.name;
  if (lakeAmount(position.x, position.z) > 0.5) return "Stillwater Lake";
  if (terrainHeight(position.x, position.z) > 38) return "The Highlands";
  if (position.z < -240) return "Pine Ridge";
  return "The Meadows";
}

function coordinate(value: number, positive: string, negative: string) {
  return `${Math.abs(Math.round(value))} ${value >= 0 ? positive : negative}`;
}

function clockTime(hour: number) {
  const minutes = Math.floor((hour % 1) * 60);
  return `${String(Math.floor(hour)).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

function timeOfDay(hour: number) {
  if (hour < 5.5 || hour >= 20) return "NIGHT";
  if (hour < 8) return "DAWN";
  if (hour < 12) return "MORNING";
  if (hour < 17) return "AFTERNOON";
  return "EVENING";
}

function drawMapBase(canvas: HTMLCanvasElement, centerX: number, centerZ: number, range: number) {
  const context = canvas.getContext("2d");
  if (!context) return;
  const size = canvas.width;
  const step = 4;
  context.fillStyle = "#d5d8bd";
  context.fillRect(0, 0, size, size);

  for (let py = 0; py < size; py += step) {
    for (let px = 0; px < size; px += step) {
      const x = centerX + (px / size - 0.5) * range * 2;
      const z = centerZ + (py / size - 0.5) * range * 2;
      const height = terrainHeight(x, z);
      const lake = lakeAmount(x, z);
      if (lake > 0.57) {
        context.fillStyle = lake > 0.9 ? "#9dbdb4" : "#b7ccc0";
      } else {
        const hill = Math.max(0, Math.min(1, (height - 6) / 100));
        const patch = (Math.sin(x * 0.067 + Math.sin(z * 0.03)) + Math.cos(z * 0.052 + x * 0.015)) * 0.5;
        const contour = Math.abs(height / 10 - Math.round(height / 10)) < 0.045 && height > 5 ? -9 : 0;
        const red = Math.round(190 + hill * 38 + patch * 5 + contour);
        const green = Math.round(199 + hill * 29 + patch * 5 + contour);
        const blue = Math.round(166 + hill * 49 + patch * 5 + contour);
        context.fillStyle = `rgb(${red}, ${green}, ${blue})`;
      }
      context.fillRect(px, py, step, step);
    }
  }

  const mapX = (x: number) => ((x - centerX) / (range * 2) + 0.5) * size;
  const mapY = (z: number) => ((z - centerZ) / (range * 2) + 0.5) * size;
  context.beginPath();
  for (let i = 0; i <= 200; i += 1) {
    const z = centerZ - range + (i / 200) * range * 2;
    const x = trailX(z);
    if (i === 0) context.moveTo(mapX(x), mapY(z));
    else context.lineTo(mapX(x), mapY(z));
  }
  context.strokeStyle = "rgba(160, 144, 106, 0.62)";
  context.lineWidth = Math.max(2, size / 100);
  context.stroke();
  context.strokeStyle = "rgba(247, 241, 216, 0.88)";
  context.lineWidth = Math.max(1, size / 170);
  context.stroke();

  for (const road of ROAD_SAMPLES) {
    context.beginPath();
    road.forEach((point, index) => {
      if (index === 0) context.moveTo(mapX(point.x), mapY(point.z));
      else context.lineTo(mapX(point.x), mapY(point.z));
    });
    context.strokeStyle = "rgba(154, 132, 96, 0.7)";
    context.lineWidth = Math.max(2.5, size / 95);
    context.stroke();
    context.strokeStyle = "rgba(249, 242, 219, 0.9)";
    context.lineWidth = Math.max(1.2, size / 170);
    context.stroke();
  }
  context.beginPath();
  context.moveTo(mapX(BRIDGE_MAP.fromX), mapY(BRIDGE_MAP.z));
  context.lineTo(mapX(BRIDGE_MAP.toX), mapY(BRIDGE_MAP.z));
  context.strokeStyle = "#817361";
  context.lineWidth = Math.max(1.5, size / 180);
  context.stroke();

  context.strokeStyle = "rgba(90, 112, 91, 0.1)";
  context.lineWidth = 1;
  const grid = size / 4;
  for (let i = 1; i < 4; i += 1) {
    context.beginPath();
    context.moveTo(i * grid, 0);
    context.lineTo(i * grid, size);
    context.moveTo(0, i * grid);
    context.lineTo(size, i * grid);
    context.stroke();
  }

  const mapScale = size / (range * 2);
  for (const village of VILLAGES) {
    const x = mapX(village.x);
    const y = mapY(village.z);
    for (const house of village.houses) {
      context.save();
      context.translate(mapX(house.x), mapY(house.z));
      context.rotate(-house.rotation);
      context.fillStyle = "#8b7963";
      context.fillRect(-house.width * mapScale / 2, -house.depth * mapScale / 2, house.width * mapScale, house.depth * mapScale);
      context.strokeStyle = "rgba(247, 243, 220, 0.8)";
      context.lineWidth = 1;
      context.strokeRect(-house.width * mapScale / 2, -house.depth * mapScale / 2, house.width * mapScale, house.depth * mapScale);
      context.restore();
    }
    context.fillStyle = "#48634c";
    context.beginPath();
    context.arc(x, y, size > 300 ? 4 : 3, 0, Math.PI * 2);
    context.fill();
    if (size > 300) {
      context.font = "700 10px 'DM Sans', sans-serif";
      context.fillStyle = "#405a47";
      context.fillText(village.name.toUpperCase(), x + 8, y - 8);
    }
  }
  if (size > 300) {
    context.font = "600 9px 'DM Sans', sans-serif";
    for (const landmark of LANDMARKS) {
      const x = mapX(landmark.x);
      const y = mapY(landmark.z);
      context.fillStyle = "#766d59";
      context.beginPath();
      context.moveTo(x, y - 4);
      context.lineTo(x + 4, y + 3);
      context.lineTo(x - 4, y + 3);
      context.closePath();
      context.fill();
      context.fillText(landmark.name.toUpperCase(), x + 7, y - 4);
    }
  }
}

function WorldMap({ position, large = false }: { position: WorldPosition; large?: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cacheRef = useRef<{ canvas: HTMLCanvasElement; x: number; z: number } | null>(null);
  const size = large ? 520 : 220;
  const range = large ? 520 : 145;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext("2d");
    if (!context) return;
    let cache = cacheRef.current;
    if (!cache || Math.hypot(position.x - cache.x, position.z - cache.z) > (large ? 25 : 9)) {
      const base = document.createElement("canvas");
      base.width = size;
      base.height = size;
      drawMapBase(base, position.x, position.z, range);
      cache = { canvas: base, x: position.x, z: position.z };
      cacheRef.current = cache;
    }
    context.clearRect(0, 0, size, size);
    context.drawImage(cache.canvas, 0, 0);
    const playerX = size / 2 + ((position.x - cache.x) / (range * 2)) * size;
    const playerY = size / 2 + ((position.z - cache.z) / (range * 2)) * size;
    context.save();
    context.translate(playerX, playerY);
    context.rotate((position.bearing * Math.PI) / 180);
    context.shadowColor = "rgba(31, 51, 40, 0.35)";
    context.shadowBlur = 6;
    context.fillStyle = "#f6f2de";
    context.beginPath();
    context.arc(0, 0, large ? 14 : 12, 0, Math.PI * 2);
    context.fill();
    context.shadowBlur = 0;
    context.fillStyle = "#354f3e";
    context.beginPath();
    context.moveTo(0, large ? -10 : -9);
    context.lineTo(large ? 6 : 5, large ? 7 : 6);
    context.lineTo(0, 3);
    context.lineTo(large ? -6 : -5, large ? 7 : 6);
    context.closePath();
    context.fill();
    context.restore();
  }, [position, large, range, size]);

  return <canvas ref={canvasRef} width={size} height={size} aria-label="Map of the surrounding landscape" />;
}

function CompassHeading({ bearing }: { bearing: number }) {
  const heading = direction(bearing);
  return (
    <div className="compass-heading" aria-label={`Facing ${heading}, ${Math.round(bearing)} degrees`}>
      <span className="compass-ticks compass-ticks-left" />
      <span className="compass-letter">{heading}</span>
      <span className="compass-ticks compass-ticks-right" />
      <span className="compass-pointer" />
      <span className="compass-degrees">{String(Math.round(bearing) % 360).padStart(3, "0")}&deg;</span>
    </div>
  );
}

function TouchJoystick({ world }: { world: WanderWorld | null }) {
  const [stick, setStick] = useState({ x: 0, y: 0 });
  const pointer = useRef<number | null>(null);

  const update = (event: ReactPointerEvent<HTMLDivElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    const radius = bounds.width * 0.36;
    let x = (event.clientX - (bounds.left + bounds.width / 2)) / radius;
    let y = (event.clientY - (bounds.top + bounds.height / 2)) / radius;
    const magnitude = Math.hypot(x, y);
    if (magnitude > 1) {
      x /= magnitude;
      y /= magnitude;
    }
    setStick({ x, y });
    world?.setTouchMovement(x, y);
  };

  const end = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (pointer.current !== event.pointerId) return;
    pointer.current = null;
    setStick({ x: 0, y: 0 });
    world?.setTouchMovement(0, 0);
  };

  return (
    <div
      className="touch-joystick"
      role="application"
      aria-label="Movement joystick"
      onPointerDown={(event) => {
        event.preventDefault();
        pointer.current = event.pointerId;
        event.currentTarget.setPointerCapture(event.pointerId);
        update(event);
      }}
      onPointerMove={(event) => {
        if (pointer.current === event.pointerId) update(event);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <span className="joystick-inner" style={{ transform: `translate(${stick.x * 30}px, ${stick.y * 30}px)` }} />
    </div>
  );
}

function KeyboardGuide({ locked }: { locked: boolean }) {
  return (
    <div className="keyboard-guide" aria-label="Game controls">
      <div className="guide-group">
        <div className="wasd-keys" aria-hidden="true"><kbd>W</kbd><div><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd></div></div>
        <span><b>W A S D</b><small>to move</small></span>
      </div>
      <div className="guide-divider" />
      <div className="guide-group">
        <Mouse size={22} strokeWidth={1.4} />
        <span><b>MOUSE</b><small>{locked ? "to look around" : "click to look"}</small></span>
      </div>
      <div className="guide-divider" />
      <div className="guide-group guide-run">
        <kbd className="shift-key">SHIFT</kbd>
        <span><b>HOLD SHIFT</b><small>to move faster</small></span>
      </div>
    </div>
  );
}

export default function App() {
  const hostRef = useRef<HTMLDivElement>(null);
  const worldRef = useRef<WanderWorld | null>(null);
  const [worldReady, setWorldReady] = useState(false);
  const [worldError, setWorldError] = useState(false);
  const [started, setStarted] = useState(false);
  const [position, setPosition] = useState<WorldPosition>(START_POSITION);
  const [locked, setLocked] = useState(false);
  const [panel, setPanel] = useState<Panel>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [quality, setQuality] = useState<GraphicsQuality>("auto");
  const [dayNightCycle, setDayNightCycle] = useState(true);
  const [graphicsSupport, setGraphicsSupport] = useState({ ambientOcclusion: true, softwareRendering: false });

  useEffect(() => {
    let world: WanderWorld | null = null;
    const timer = window.setTimeout(() => {
      if (!hostRef.current) return;
      try {
        world = new WanderWorld(hostRef.current, {
          onPosition: setPosition,
          onPointerLock: setLocked,
        });
        worldRef.current = world;
        setGraphicsSupport(world.graphicsCapabilities());
        setWorldReady(true);
      } catch (error) {
        console.error("Unable to start the 3D world", error);
        setWorldError(true);
      }
    }, 100);
    return () => {
      window.clearTimeout(timer);
      world?.dispose();
      if (worldRef.current === world) worldRef.current = null;
    };
  }, []);

  useEffect(() => {
    worldRef.current?.setActive(started && panel === null);
  }, [started, panel, worldReady]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.repeat) return;
      if (event.key.toLowerCase() === "m") {
        setPanel((current) => current === "map" ? null : "map");
      } else if (event.key === "Escape") {
        if (document.pointerLockElement) document.exitPointerLock();
        setPanel(null);
      } else if (event.key === "?") {
        setPanel((current) => current === "controls" ? null : "controls");
      }
    };
    const onFullscreen = () => setFullscreen(Boolean(document.fullscreenElement));
    window.addEventListener("keydown", onKey);
    document.addEventListener("fullscreenchange", onFullscreen);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.removeEventListener("fullscreenchange", onFullscreen);
    };
  }, []);

  const startExploring = () => {
    if (!worldReady || !worldRef.current) return;
    setStarted(true);
    worldRef.current.setActive(true);
    if (!window.matchMedia("(pointer: coarse)").matches) worldRef.current.lockPointer();
  };

  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
    } catch {
      // Some embedded browsers do not allow fullscreen.
    }
  };

  const openPanel = useCallback((next: Panel) => {
    if (document.pointerLockElement) document.exitPointerLock();
    setPanel(next);
  }, []);

  const resetPosition = () => {
    worldRef.current?.reset();
    setPosition((current) => ({ ...START_POSITION, hour: current.hour }));
    setPanel(null);
  };

  const currentVillage = villageAt(position.x, position.z);
  const currentHouse = houseAt(position.x, position.z);

  return (
    <main className={`game-shell ${started ? "is-playing" : "is-intro"}`}>
      <div className="cover-scene" aria-hidden="true" />
      <div ref={hostRef} className="world-host" />
      <div className="scene-shade" aria-hidden="true" />

      <header className="top-bar">
        <div className="brand" aria-label="Wander, a quiet open world">
          <MountainMark />
          <div className="brand-words"><strong>WANDER<span>.</span></strong><small>A QUIET OPEN WORLD</small></div>
        </div>
        <CompassHeading bearing={position.bearing} />
        <div className="top-actions">
          <div className="daylight">{timeOfDay(position.hour) === "NIGHT" ? <Moon size={17} strokeWidth={1.5} /> : <Sun size={17} strokeWidth={1.5} />}<span>{timeOfDay(position.hour)} <b>{clockTime(position.hour)}</b></span><i /></div>
          <button className="top-text-button" onClick={() => openPanel("controls")} aria-label="Open controls and settings">CONTROLS</button>
          <button className="icon-button fullscreen-button" onClick={toggleFullscreen} aria-label={fullscreen ? "Exit fullscreen" : "Enter fullscreen"}>
            {fullscreen ? <Minimize size={17} /> : <Expand size={17} />}
          </button>
        </div>
      </header>

      {!started && (
        <section className="intro-copy" aria-labelledby="intro-title">
          <div className="eyebrow"><span /> A LITTLE WORLD OF YOUR OWN</div>
          <h1 id="intro-title">Wander<br /><em>somewhere new.</em></h1>
          <p>Three quiet villages. No crowds. Just a world to wander.</p>
          <button className="start-button" onClick={startExploring} disabled={!worldReady}>
            <span>{worldError ? "3D NOT AVAILABLE" : worldReady ? "START WANDERING" : "PREPARING YOUR WORLD"}</span>
            <ArrowUpRight size={19} strokeWidth={1.6} />
          </button>
          {worldError ? (
            <span className="intro-note error-note">Your browser needs WebGL to explore this world.</span>
          ) : (
            <span className="intro-note"><span /> THREE VILLAGES. EVERY HOUSE IS OPEN.</span>
          )}
        </section>
      )}

      {started && <div className="crosshair" aria-hidden="true"><span /><span /></div>}

      <div className="bottom-hud">
        <div className="location-block">
          <div className="location-kicker"><MapPin size={13} strokeWidth={1.6} /> YOU ARE HERE <span /> {currentVillage ? String(VILLAGES.indexOf(currentVillage) + 1).padStart(2, "0") : "--"}</div>
          <div className="location-name">{locationName(position)}</div>
          <div className="location-caption">{currentHouse ? "Inside an open village house" : currentVillage ? "Every house has an open door" : "A good place to just be"}<span>.</span></div>
        </div>

        <KeyboardGuide locked={locked} />

        <button className="minimap-button" onClick={() => openPanel("map")} aria-label="Open the world map, shortcut M">
          <div className="minimap-frame">
            <WorldMap position={position} />
            <span className="map-north">N</span>
            <span className="map-corner map-corner-one" /><span className="map-corner map-corner-two" />
          </div>
          <div className="minimap-label"><span><MapIcon size={13} /> VIEW MAP</span><kbd>M</kbd></div>
        </button>
      </div>

      <div className="screen-footer" aria-hidden="true">
        <span>EST. SOMEWHERE</span>
        <span className="footer-center">A WORLD MADE FOR WANDERING</span>
        <span>TAKE THE LONG WAY HOME</span>
      </div>

      {started && !panel && <TouchJoystick world={worldRef.current} />}
      {started && !panel && <div className="touch-look-hint">SWIPE TO LOOK AROUND <MoveUpRight size={14} /></div>}
      {started && !locked && !panel && <div className="relock-hint">CLICK ANYWHERE TO LOOK AROUND</div>}

      {panel && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setPanel(null); }}>
          <section className={`modal-panel ${panel === "map" ? "map-panel" : "controls-panel"}`} role="dialog" aria-modal="true" aria-labelledby="panel-title">
            <div className="modal-topline">
              <span><MountainMark /> WANDER / {panel === "map" ? "YOUR SURROUNDINGS" : "A LITTLE HELP"}</span>
              <button className="modal-close" onClick={() => setPanel(null)} aria-label="Close"><X size={19} /></button>
            </div>
            {panel === "map" ? (
              <>
                <div className="modal-heading"><div><span className="modal-eyebrow">A LITTLE PERSPECTIVE</span><h2 id="panel-title">Find your own way.</h2><p>Three quiet villages. Every house is open.</p></div><Compass size={31} strokeWidth={1.1} /></div>
                <div className="large-map-wrap">
                  <WorldMap position={position} large />
                  <span className="large-map-north">N <span>&uarr;</span></span>
                  <div className="map-coordinate">{coordinate(position.x, "E", "W")} &nbsp; / &nbsp; {coordinate(-position.z, "N", "S")}</div>
                </div>
                <div className="map-bottom"><span><LocateFixed size={15} /> YOU ARE HERE <b>{locationName(position)}</b></span><button onClick={() => setPanel(null)}>BACK TO EXPLORING <ArrowRight size={16} /></button></div>
              </>
            ) : (
              <>
                <div className="modal-heading"><div><span className="modal-eyebrow">THE BASICS</span><h2 id="panel-title">Make yourself at home.</h2><p>All you have to do is wander.</p></div></div>
                <div className="world-settings">
                  <div className="settings-label">WORLD SETTINGS</div>
                  <label className="settings-row"><span><strong>Graphics quality</strong><small>{graphicsSupport.ambientOcclusion ? "High enables ambient occlusion." : "Ambient occlusion needs a supported GPU."}</small></span><select aria-label="Graphics quality" value={quality} onChange={(event) => { const next = event.target.value as GraphicsQuality; setQuality(next); worldRef.current?.setQuality(next); }}><option value="auto">Automatic</option><option value="low">Low</option><option value="balanced">Balanced</option><option value="high" disabled={!graphicsSupport.ambientOcclusion}>High + AO</option></select></label>
                  <label className="settings-row time-setting"><span><strong>Time of day</strong><small>{timeOfDay(position.hour)} / {clockTime(position.hour)}</small></span><input aria-label="Time of day" type="range" min="0" max="23.75" step="0.25" value={position.hour} onChange={(event) => worldRef.current?.setTime(Number(event.target.value))} /></label>
                  <label className="cycle-setting"><input type="checkbox" checked={dayNightCycle} onChange={(event) => { setDayNightCycle(event.target.checked); worldRef.current?.setDayNightCycle(event.target.checked); }} /> <span>Day and night cycle</span></label>
                </div>
                <div className="controls-list">
                  <div><span className="controls-icon"><span className="control-key">W A S D</span></span><p><strong>Move around</strong><small>Use the arrow keys, too.</small></p></div>
                  <div><span className="controls-icon"><Mouse size={23} strokeWidth={1.3} /></span><p><strong>Look around</strong><small>Click to capture your mouse, or drag to look. Esc releases it.</small></p></div>
                  <div><span className="controls-icon"><span className="control-key">SHIFT</span></span><p><strong>Pick up the pace</strong><small>Hold shift while moving to run.</small></p></div>
                  <div><span className="controls-icon"><span className="control-key">M</span></span><p><strong>Open your map</strong><small>See where your wandering has taken you.</small></p></div>
                  <div className="mobile-controls-row"><span className="controls-icon"><MoveUpRight size={22} /></span><p><strong>On a touchscreen</strong><small>Use the joystick to move and swipe the world to look.</small></p></div>
                </div>
                <div className="controls-bottom"><button className="reset-button" onClick={resetPosition}><RotateCcw size={15} /> RETURN TO START</button><button className="back-button" onClick={() => setPanel(null)}>BACK TO THE WORLD <ChevronRight size={17} /></button></div>
              </>
            )}
          </section>
        </div>
      )}
      <span className="sr-only">Explore three empty villages with open houses and no animals or other characters.</span>
    </main>
  );
}