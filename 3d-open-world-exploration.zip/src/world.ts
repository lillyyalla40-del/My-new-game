import * as THREE from "three";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { SSAOPass } from "three/addons/postprocessing/SSAOPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import { createVillageMeshes, houseWallBlocks, VILLAGES, villageObstacleBlocks } from "./villages";
import { createSettlementRoads } from "./routes";
import { VegetationManager } from "./vegetation";
import { bridgeSurface, createScenery, sceneryBlocks } from "./scenery";

export type WorldPosition = {
  x: number;
  z: number;
  bearing: number;
  hour: number;
};

export type GraphicsQuality = "auto" | "low" | "balanced" | "high";

const TILE_SIZE = 400;
const TILE_SEGMENTS = 96;
const WATER_LEVEL = 0.25;
const LAKE_X = 53;
const LAKE_Z = -128;
const LAKE_RX = 64;
const LAKE_RZ = 45;
const START_Z = 65;

const clamp01 = (value: number) => Math.max(0, Math.min(1, value));
const smoothstep = (a: number, b: number, value: number) => {
  const t = clamp01((value - a) / (b - a));
  return t * t * (3 - 2 * t);
};

function hash(x: number, z: number) {
  const n = Math.sin(x * 127.1 + z * 311.7) * 43758.5453123;
  return n - Math.floor(n);
}

function noise(x: number, z: number) {
  const ix = Math.floor(x);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fz = z - iz;
  const ux = fx * fx * (3 - 2 * fx);
  const uz = fz * fz * (3 - 2 * fz);
  const a = hash(ix, iz);
  const b = hash(ix + 1, iz);
  const c = hash(ix, iz + 1);
  const d = hash(ix + 1, iz + 1);
  return (a + (b - a) * ux) * (1 - uz) + (c + (d - c) * ux) * uz;
}

export function trailX(z: number) {
  return Math.sin(z * 0.014) * 17 + Math.sin(z * 0.0045) * 25;
}

export function lakeAmount(x: number, z: number) {
  const distance = Math.hypot((x - LAKE_X) / LAKE_RX, (z - LAKE_Z) / LAKE_RZ);
  return 1 - smoothstep(0.72, 1.14, distance);
}

const peaks = [
  { x: -175, z: -344, rx: 155, rz: 130, h: 132 },
  { x: -44, z: -405, rx: 155, rz: 155, h: 172 },
  { x: 102, z: -362, rx: 145, rz: 135, h: 141 },
  { x: 250, z: -410, rx: 150, rz: 150, h: 116 },
  { x: -365, z: -445, rx: 175, rz: 170, h: 120 },
  { x: 410, z: -500, rx: 190, rz: 190, h: 140 },
  { x: -400, z: 330, rx: 210, rz: 180, h: 105 },
  { x: 390, z: 360, rx: 200, rz: 190, h: 115 },
];

function naturalTerrainHeight(x: number, z: number) {
  let height =
    1.1 +
    (noise(x * 0.009, z * 0.009) - 0.5) * 8 +
    (noise(x * 0.027 + 12, z * 0.027 - 8) - 0.5) * 2.5 +
    (noise(x * 0.075 - 4, z * 0.075 + 9) - 0.5) * 0.55;

  const overlook = Math.exp(-((x - 8) ** 2 / 8500 + (z - 85) ** 2 / 10000));
  height += overlook * 9;

  let mountain = 0;
  for (const peak of peaks) {
    const distance = Math.hypot((x - peak.x) / peak.rx, (z - peak.z) / peak.rz);
    const shape = Math.max(0, 1 - distance);
    mountain = Math.max(mountain, Math.pow(shape, 1.18) * peak.h);
  }
  const crags = (noise(x * 0.039 + 23, z * 0.039) - 0.5) * 0.28;
  const ridges = 1 - Math.abs(noise(x * 0.024 - 8, z * 0.024 + 31) * 2 - 1);
  height += mountain * (0.78 + crags + ridges * 0.18);

  const lake = lakeAmount(x, z);
  height = THREE.MathUtils.lerp(height, -3.2 + noise(x * 0.045, z * 0.045) * 0.4, lake);
  height -= (1 - smoothstep(2.5, 6.7, Math.abs(x - trailX(z)))) * 0.12;
  return height;
}

const villageHeights = VILLAGES.map((village) => Math.max(WATER_LEVEL + 1.2, naturalTerrainHeight(village.x, village.z)));

export function terrainHeight(x: number, z: number) {
  let height = naturalTerrainHeight(x, z);
  for (let i = 0; i < VILLAGES.length; i += 1) {
    const village = VILLAGES[i];
    const distance = Math.hypot(x - village.x, z - village.z);
    if (distance < 100) {
      const shoreProtection = 1 - smoothstep(0.02, 0.38, lakeAmount(x, z));
      height = THREE.MathUtils.lerp(height, villageHeights[i], (1 - smoothstep(78, 100, distance)) * shoreProtection);
    }
  }
  return height;
}

export const START_POSITION: WorldPosition = {
  x: trailX(START_Z),
  z: START_Z,
  bearing: 0,
  hour: 15,
};

function makeGroundTexture() {
  const texture = new THREE.TextureLoader().load("/textures/meadow.jpg");
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(30, 30);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;
  return texture;
}

function makeDirtTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const context = canvas.getContext("2d")!;
  context.fillStyle = "#dfd6c2";
  context.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 24000; i += 1) {
    const x = hash(i, 1) * 512;
    const y = hash(i, 7) * 512;
    const light = Math.floor(100 + hash(i, 9) * 125);
    context.fillStyle = `rgba(${light}, ${Math.floor(light * 0.92)}, ${Math.floor(light * 0.76)}, ${0.04 + hash(i, 3) * 0.17})`;
    context.fillRect(x, y, 0.8 + hash(i, 4) * 3, 0.7 + hash(i, 5) * 2);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(18, 18);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}

function makeWaterTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 256;
  const context = canvas.getContext("2d")!;
  context.fillStyle = "#9bbdb5";
  context.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 340; i += 1) {
    const x = hash(i, 10) * 256;
    const y = hash(i, 11) * 256;
    context.strokeStyle = `rgba(229, 240, 215, ${0.08 + hash(i, 12) * 0.18})`;
    context.lineWidth = 0.5 + hash(i, 13);
    context.beginPath();
    context.moveTo(x, y);
    context.quadraticCurveTo(x + 6, y - 1, x + 12 + hash(i, 14) * 20, y);
    context.stroke();
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(3, 2);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function makeWaterNormalTexture() {
  const size = 128;
  const data = new Uint8Array(size * size * 4);
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const a = x / size * Math.PI * 2;
      const b = y / size * Math.PI * 2;
      const dx = Math.cos(a * 5 + Math.sin(b * 3)) * 0.15 + Math.cos(a * 9 + b * 4) * 0.07;
      const dy = Math.sin(b * 5 + Math.cos(a * 2)) * 0.14 + Math.sin(b * 8 - a * 3) * 0.06;
      const offset = (y * size + x) * 4;
      data[offset] = Math.round((dx * 0.5 + 0.5) * 255);
      data[offset + 1] = Math.round((dy * 0.5 + 0.5) * 255);
      data[offset + 2] = 250;
      data[offset + 3] = 255;
    }
  }
  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(5, 4);
  texture.needsUpdate = true;
  return texture;
}

function makeWaterGeometry() {
  const positions: number[] = [];
  const uvs: number[] = [];
  const indices: number[] = [];
  const rings = 18;
  const segments = 80;
  for (let ring = 0; ring <= rings; ring += 1) {
    const radius = ring / rings;
    for (let segment = 0; segment <= segments; segment += 1) {
      const angle = segment / segments * Math.PI * 2;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      positions.push(x, y, 0);
      uvs.push((x + 1) / 2, (y + 1) / 2);
      if (ring < rings && segment < segments) {
        const index = ring * (segments + 1) + segment;
        indices.push(index, index + segments + 1, index + 1, index + 1, index + segments + 1, index + segments + 2);
      }
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geometry.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return geometry;
}

function makeCloudTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 256;
  const context = canvas.getContext("2d")!;
  const puffs = [
    [132, 151, 92], [208, 118, 106], [282, 134, 105],
    [361, 158, 86], [238, 171, 115], [334, 178, 94],
  ];
  for (const [x, y, radius] of puffs) {
    const gradient = context.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, "rgba(255, 255, 246, 0.4)");
    gradient.addColorStop(0.5, "rgba(255, 255, 246, 0.19)");
    gradient.addColorStop(1, "rgba(255, 255, 246, 0)");
    context.fillStyle = gradient;
    context.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function makeSky() {
  const material = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      uSunDirection: { value: new THREE.Vector3(0.55, 0.5, -0.75).normalize() },
      uDaylight: { value: 1 },
      uTwilight: { value: 0 },
      uSkyTime: { value: 0 },
      uCloudDetail: { value: 1 },
    },
    vertexShader: `
      varying vec3 vDirection;
      void main() {
        vDirection = normalize(position);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      varying vec3 vDirection;
      uniform vec3 uSunDirection;
      uniform float uDaylight;
      uniform float uTwilight;
      uniform float uSkyTime;
      uniform float uCloudDetail;
      float cloudHash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
      float cloudNoise(vec2 p) {
        vec2 cell = floor(p);
        vec2 f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        return mix(mix(cloudHash(cell), cloudHash(cell + vec2(1.0, 0.0)), f.x),
          mix(cloudHash(cell + vec2(0.0, 1.0)), cloudHash(cell + vec2(1.0, 1.0)), f.x), f.y);
      }
      void main() {
        vec3 direction = normalize(vDirection);
        float elevation = max(direction.y, 0.0);
        vec3 horizon = mix(vec3(0.045, 0.075, 0.13), vec3(0.63, 0.76, 0.74), uDaylight);
        vec3 blue = mix(vec3(0.012, 0.025, 0.065), vec3(0.15, 0.36, 0.50), uDaylight);
        vec3 sky = mix(horizon, blue, smoothstep(0.0, 0.8, elevation));
        sky += vec3(0.18, 0.08, 0.025) * uTwilight * (1.0 - smoothstep(0.0, 0.35, elevation));
        if (uCloudDetail > 0.5) {
          vec2 cloudUv = direction.xz / max(direction.y + 0.35, 0.35) * 3.5 + vec2(uSkyTime * 0.002, 0.0);
          float cloudField = cloudNoise(cloudUv) * 0.7 + cloudNoise(cloudUv * 2.1) * 0.3;
          float cloud = smoothstep(0.56, 0.78, cloudField) * smoothstep(0.02, 0.26, elevation);
          sky = mix(sky, vec3(0.78, 0.82, 0.78), cloud * 0.2 * uDaylight);
        }
        float sunAngle = max(dot(direction, normalize(uSunDirection)), 0.0);
        sky += vec3(0.26, 0.19, 0.10) * pow(sunAngle, 28.0) * uDaylight;
        sky += vec3(0.65, 0.54, 0.35) * pow(sunAngle, 900.0) * uDaylight;
        float moonAngle = max(dot(direction, normalize(-uSunDirection)), 0.0);
        sky += vec3(0.48, 0.54, 0.65) * pow(moonAngle, 1200.0) * (1.0 - uDaylight);
        vec3 cell = floor(direction * 420.0);
        float star = fract(sin(dot(cell, vec3(127.1, 311.7, 74.7))) * 43758.5453);
        sky += vec3(0.38, 0.43, 0.48) * step(0.9983, star) * (1.0 - uDaylight) * smoothstep(0.05, 0.4, elevation);
        gl_FragColor = vec4(sky, 1.0);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }
    `,
  });
  return new THREE.Mesh(new THREE.SphereGeometry(1600, 32, 20), material);
}

type WorldOptions = {
  onPosition: (position: WorldPosition) => void;
  onPointerLock: (locked: boolean) => void;
};

export class WanderWorld {
  private container: HTMLElement;
  private options: WorldOptions;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private sky = makeSky();
  private hemisphere = new THREE.HemisphereLight("#e5f1e9", "#657453", 1.4);
  private sunlight = new THREE.DirectionalLight("#fff1d1", 2.1);
  private fillLight = new THREE.DirectionalLight("#c8dce2", 0.25);
  private composer: EffectComposer | null = null;
  private ssaoPass: SSAOPass | null = null;
  private outputPass: OutputPass | null = null;
  private softwareRenderer = false;
  private aoSupported = false;
  private shadowEnabled = false;
  private quality: GraphicsQuality = "auto";
  private hour = START_POSITION.hour;
  private cycleEnabled = true;
  private fogDay = new THREE.Color("#b7c8be");
  private fogNight = new THREE.Color("#293b50");
  private sunWarm = new THREE.Color("#ffd4a2");
  private sunWhite = new THREE.Color("#fff0d5");
  private cloudDay = new THREE.Color("#fffaf0");
  private cloudNight = new THREE.Color("#66758d");
  private sunDirection = new THREE.Vector3();
  private clouds: Array<{ sprite: THREE.Sprite; x: number; y: number; z: number; phase: number }> = [];
  private terrain = new Map<string, THREE.Mesh>();
  private terrainMaterial: THREE.MeshStandardMaterial;
  private groundTexture = makeGroundTexture();
  private dirtTexture = makeDirtTexture();
  private waterTexture = makeWaterTexture();
  private waterNormalTexture = makeWaterNormalTexture();
  private grassTime = { value: 0 };
  private vegetation: VegetationManager;
  private rotors: THREE.Group[] = [];
  private trail: THREE.Mesh | null = null;
  private trailCenter = Number.NaN;
  private position = new THREE.Vector3(START_POSITION.x, 0, START_POSITION.z);
  private yaw = 0;
  private pitch = -0.1;
  private keys = new Set<string>();
  private touchMovement = { x: 0, y: 0 };
  private touchLook: { id: number; x: number; y: number } | null = null;
  private dragLook: { x: number; y: number } | null = null;
  private active = false;
  private movingTime = 0;
  private lastTime = 0;
  private lastHud = 0;
  private renderScale = 1;
  private performanceTime = 0;
  private performanceFrames = 0;
  private frame = 0;
  private disposed = false;
  private resources: Array<THREE.BufferGeometry | THREE.Material | THREE.Texture> = [];

  constructor(container: HTMLElement, options: WorldOptions) {
    this.container = container;
    this.options = options;
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    const gl = this.renderer.getContext();
    const rendererInfo = gl.getExtension("WEBGL_debug_renderer_info");
    const rendererName = rendererInfo ? String(gl.getParameter(rendererInfo.UNMASKED_RENDERER_WEBGL)) : "";
    this.softwareRenderer = /swiftshader|llvmpipe|software/i.test(rendererName);
    this.aoSupported = !this.softwareRenderer && Boolean(gl.getExtension("EXT_color_buffer_float"));
    this.renderScale = this.softwareRenderer
      ? Math.min(1, 320 / Math.max(container.clientWidth, container.clientHeight))
      : Math.min(window.devicePixelRatio || 1, 1.25);
    this.renderer.setPixelRatio(this.renderScale);
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.setAttribute("aria-label", "A three-dimensional landscape to explore");
    this.container.appendChild(this.renderer.domElement);

    this.camera = new THREE.PerspectiveCamera(65, container.clientWidth / container.clientHeight, 0.1, 1800);
    this.camera.rotation.order = "YXZ";
    this.position.y = terrainHeight(this.position.x, this.position.z) + 2.2;
    this.camera.position.copy(this.position);
    this.camera.rotation.set(this.pitch, this.yaw, 0);

    this.scene.fog = new THREE.Fog("#b8c9bc", 230, 900);
    this.scene.add(this.sky);
    this.addClouds();
    this.scene.add(this.hemisphere);
    this.sunlight.shadow.mapSize.set(768, 768);
    this.sunlight.shadow.camera.left = -60;
    this.sunlight.shadow.camera.right = 60;
    this.sunlight.shadow.camera.top = 60;
    this.sunlight.shadow.camera.bottom = -60;
    this.sunlight.shadow.camera.near = 1;
    this.sunlight.shadow.camera.far = 360;
    this.sunlight.shadow.bias = -0.00018;
    this.sunlight.shadow.normalBias = 0.04;
    this.scene.add(this.sunlight, this.sunlight.target);
    this.fillLight.position.set(-150, 80, 100);
    this.scene.add(this.fillLight);

    this.terrainMaterial = new THREE.MeshStandardMaterial({
      map: this.groundTexture,
      vertexColors: true,
      roughness: 1,
    });
    this.terrainMaterial.onBeforeCompile = (shader) => {
      shader.fragmentShader = shader.fragmentShader.replace(
        "#include <map_fragment>",
        `#ifdef USE_MAP
          vec4 fineGround = texture2D(map, vMapUv);
          vec4 broadGround = texture2D(map, vMapUv * 0.27 + vec2(0.31, 0.17));
          diffuseColor *= vec4(mix(vec3(1.0), mix(fineGround.rgb, broadGround.rgb, 0.3), 0.46), 1.0);
        #endif`,
      );
    };

    this.vegetation = new VegetationManager({
      scene: this.scene,
      heightAt: terrainHeight,
      lakeAt: lakeAmount,
      trailAt: trailX,
      wind: this.grassTime,
    });

    this.resources.push(
      this.groundTexture, this.dirtTexture, this.waterTexture, this.waterNormalTexture, this.terrainMaterial,
      this.sky.geometry, this.sky.material as THREE.Material,
    );

    this.addLake();
    const villageMeshes = createVillageMeshes(terrainHeight, this.dirtTexture);
    this.scene.add(villageMeshes.group);
    this.resources.push(...villageMeshes.resources);
    this.rotors = villageMeshes.rotors;
    const settlementRoads = createSettlementRoads(terrainHeight, this.dirtTexture);
    this.scene.add(settlementRoads.group);
    this.resources.push(...settlementRoads.resources);
    const scenery = createScenery(terrainHeight, villageMeshes.textures.wood, villageMeshes.textures.stone);
    this.scene.add(scenery.group);
    this.resources.push(...scenery.resources);
    this.setQuality("auto");
    this.updateTerrain();
    this.vegetation.update(this.position.x, this.position.z);
    this.updateTrail();
    this.updateAtmosphere();
    this.bindEvents();
    (window as unknown as { testWorld: WanderWorld }).testWorld = this;
    this.frame = requestAnimationFrame(this.animate);
  }

  private addClouds() {
    const texture = makeCloudTexture();
    const material = new THREE.SpriteMaterial({ map: texture, transparent: true, opacity: 0.58, depthWrite: false, fog: false });
    const locations = [
      [-265, 155, -500, 250], [105, 175, -540, 300], [430, 205, -580, 270],
      [-510, 185, -180, 270], [530, 160, 130, 240], [60, 190, 600, 300],
    ];
    locations.forEach(([x, y, z, width], index) => {
      const sprite = new THREE.Sprite(material);
      sprite.scale.set(width, width * 0.42, 1);
      this.scene.add(sprite);
      this.clouds.push({ sprite, x, y, z, phase: index * 1.7 });
    });
    this.resources.push(texture, material);
  }

  private addLake() {
    const geometry = makeWaterGeometry();
    const material = new THREE.MeshStandardMaterial({
      color: "#a6cbc1",
      map: this.waterTexture,
      normalMap: this.waterNormalTexture,
      normalScale: new THREE.Vector2(0.48, 0.48),
      roughness: 0.3,
      metalness: 0.08,
      transparent: true,
      opacity: 0.95,
    });
    material.onBeforeCompile = (shader) => {
      shader.uniforms.uWaterTime = this.grassTime;
      shader.vertexShader = `uniform float uWaterTime; varying vec3 vWaterWorld;\n${shader.vertexShader}`;
      shader.vertexShader = shader.vertexShader.replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
        transformed.z += sin(position.x * 22.0 + uWaterTime * 0.75) * 0.045
          + sin(position.y * 29.0 - uWaterTime * 0.55) * 0.032;`,
      );
      shader.vertexShader = shader.vertexShader.replace(
        "#include <worldpos_vertex>",
        "#include <worldpos_vertex>\n vWaterWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;",
      );
      shader.fragmentShader = `uniform float uWaterTime; varying vec3 vWaterWorld;\n${shader.fragmentShader}`;
      shader.fragmentShader = shader.fragmentShader.replace(
        "#include <dithering_fragment>",
        `float waterFresnel = pow(1.0 - clamp(dot(normalize(cameraPosition - vWaterWorld), vec3(0.0, 1.0, 0.0)), 0.0, 1.0), 3.0);
        gl_FragColor.rgb = mix(gl_FragColor.rgb, vec3(0.62, 0.75, 0.76), waterFresnel * 0.32);
        #include <dithering_fragment>`,
      );
    };
    const lake = new THREE.Mesh(geometry, material);
    lake.name = "lake";
    lake.rotation.x = -Math.PI / 2;
    lake.scale.set(LAKE_RX * 1.15, LAKE_RZ * 1.15, 1);
    lake.position.set(LAKE_X, WATER_LEVEL, LAKE_Z);
    this.scene.add(lake);
    this.resources.push(geometry, material);
  }

  private createTerrainTile(tileX: number, tileZ: number) {
    const geometry = new THREE.PlaneGeometry(TILE_SIZE, TILE_SIZE, TILE_SEGMENTS, TILE_SEGMENTS);
    geometry.rotateX(-Math.PI / 2);
    const position = geometry.attributes.position as THREE.BufferAttribute;
    const colors = new Float32Array(position.count * 3);
    const grassDark = new THREE.Color("#6e8555");
    const grassLight = new THREE.Color("#9da86b");
    const earth = new THREE.Color("#b4a17b");
    const stone = new THREE.Color("#84918a");
    const snow = new THREE.Color("#e2e9df");
    const color = new THREE.Color();

    for (let i = 0; i < position.count; i += 1) {
      const x = position.getX(i) + tileX * TILE_SIZE;
      const z = position.getZ(i) + tileZ * TILE_SIZE;
      const height = terrainHeight(x, z);
      position.setY(i, height);

      const variation = noise(x * 0.038 + 30, z * 0.038 - 3);
      color.copy(grassDark).lerp(grassLight, variation * 0.7);
      const path = 1 - smoothstep(2.8, 8, Math.abs(x - trailX(z)));
      let pathFade = 1;
      for (const village of VILLAGES) pathFade = Math.min(pathFade, smoothstep(70, 94, Math.hypot(x - village.x, z - village.z)));
      color.lerp(earth, path * pathFade * 0.72 * (1 - smoothstep(15, 32, height)));
      for (const village of VILLAGES) {
        const distance = Math.hypot(x - village.x, z - village.z);
        if (distance < 92) color.lerp(earth, (1 - smoothstep(48, 92, distance)) * 0.17);
      }
      color.lerp(stone, smoothstep(24, 68, height) * 0.86);
      const snowLine = 50 + noise(x * 0.025, z * 0.025) * 13;
      color.lerp(snow, smoothstep(snowLine, snowLine + 18, height));
      const shade = 0.91 + noise(x * 0.15, z * 0.15) * 0.18;
      colors[i * 3] = color.r * shade;
      colors[i * 3 + 1] = color.g * shade;
      colors[i * 3 + 2] = color.b * shade;
    }
    geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geometry.computeVertexNormals();
    const normals = geometry.attributes.normal as THREE.BufferAttribute;
    for (let i = 0; i < position.count; i += 1) {
      const elevation = position.getY(i);
      const slope = 1 - Math.max(0, normals.getY(i));
      if (elevation > 12 && slope > 0.12) {
        const amount = smoothstep(0.12, 0.48, slope) * smoothstep(12, 38, elevation) * 0.62;
        color.setRGB(colors[i * 3], colors[i * 3 + 1], colors[i * 3 + 2]).lerp(stone, amount);
        colors[i * 3] = color.r;
        colors[i * 3 + 1] = color.g;
        colors[i * 3 + 2] = color.b;
      }
    }
    const mesh = new THREE.Mesh(geometry, this.terrainMaterial);
    mesh.position.set(tileX * TILE_SIZE, 0, tileZ * TILE_SIZE);
    mesh.receiveShadow = true;
    return mesh;
  }

  private updateTerrain() {
    const centerX = Math.floor((this.position.x + TILE_SIZE / 2) / TILE_SIZE);
    const centerZ = Math.floor((this.position.z + TILE_SIZE / 2) / TILE_SIZE);
    const needed = new Set<string>();
    for (let x = centerX - 1; x <= centerX + 1; x += 1) {
      for (let z = centerZ - 1; z <= centerZ + 1; z += 1) {
        const key = `${x},${z}`;
        needed.add(key);
        if (!this.terrain.has(key)) {
          const tile = this.createTerrainTile(x, z);
          this.terrain.set(key, tile);
          this.scene.add(tile);
        }
      }
    }
    for (const [key, tile] of this.terrain) {
      if (!needed.has(key)) {
        this.scene.remove(tile);
        tile.geometry.dispose();
        this.terrain.delete(key);
      }
    }
  }

  private updateTrail() {
    const center = Math.round(this.position.z / 700) * 700;
    if (center === this.trailCenter) return;
    this.trailCenter = center;
    if (this.trail) {
      this.scene.remove(this.trail);
      this.trail.geometry.dispose();
      (this.trail.material as THREE.Material).dispose();
    }
    const positions: number[] = [];
    const colors: number[] = [];
    const uvs: number[] = [];
    const indices: number[] = [];
    const segments = 700;
    const earth = new THREE.Color("#b5a17a");
    for (let i = 0; i <= segments; i += 1) {
      const z = center - 1050 + (i / segments) * 2100;
      const middle = trailX(z);
      const width = 3.2 + noise(z * 0.045, 13) * 1.2;
      const offsets = [-width - 1.5, -width, width, width + 1.5];
      for (let j = 0; j < offsets.length; j += 1) {
        const x = middle + offsets[j];
        const ground = terrainHeight(x, z);
        positions.push(x, ground + 0.14, z);
        let pathFade = 1;
        for (const village of VILLAGES) pathFade = Math.min(pathFade, smoothstep(70, 94, Math.hypot(x - village.x, z - village.z)));
        colors.push(earth.r, earth.g, earth.b, j === 0 || j === 3 ? 0 : 0.68 * pathFade * (1 - smoothstep(15, 32, ground)));
        uvs.push(j / 3, (z - center + 1050) / TILE_SIZE);
      }
      if (i < segments) {
        for (let j = 0; j < 3; j += 1) {
          const a = i * 4 + j;
          indices.push(a, a + 4, a + 1, a + 1, a + 4, a + 5);
        }
      }
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute("color", new THREE.Float32BufferAttribute(colors, 4));
    geometry.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();
    const material = new THREE.MeshStandardMaterial({
      map: this.dirtTexture,
      vertexColors: true,
      roughness: 1,
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      polygonOffset: true,
      polygonOffsetFactor: -1,
    });
    this.trail = new THREE.Mesh(geometry, material);
    this.scene.add(this.trail);
  }

  private bindEvents() {
    window.addEventListener("resize", this.onResize);
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    window.addEventListener("mouseup", this.onMouseUp);
    document.addEventListener("pointerlockchange", this.onPointerLockChange);
    document.addEventListener("mousemove", this.onMouseMove);
    this.renderer.domElement.addEventListener("click", this.onCanvasClick);
    this.renderer.domElement.addEventListener("mousedown", this.onMouseDown);
    this.renderer.domElement.addEventListener("touchstart", this.onTouchStart, { passive: false });
    this.renderer.domElement.addEventListener("touchmove", this.onTouchMove, { passive: false });
    this.renderer.domElement.addEventListener("touchend", this.onTouchEnd);
    this.renderer.domElement.addEventListener("touchcancel", this.onTouchEnd);
  }

  private onResize = () => {
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    if (!width || !height) return;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.composer?.setSize(width, height);
  };

  private onKeyDown = (event: KeyboardEvent) => {
    if (!this.active) return;
    const key = event.key.toLowerCase();
    if (["w", "a", "s", "d", "arrowup", "arrowleft", "arrowdown", "arrowright", "shift"].includes(key)) {
      event.preventDefault();
      this.keys.add(key);
    }
  };

  private onKeyUp = (event: KeyboardEvent) => {
    this.keys.delete(event.key.toLowerCase());
  };

  private onBlur = () => {
    this.keys.clear();
    this.touchMovement = { x: 0, y: 0 };
  };

  private onPointerLockChange = () => {
    const locked = document.pointerLockElement === this.renderer.domElement;
    if (locked) this.dragLook = null;
    this.options.onPointerLock(locked);
  };

  private onMouseMove = (event: MouseEvent) => {
    if (!this.active) return;
    if (document.pointerLockElement === this.renderer.domElement) {
      this.look(event.movementX, event.movementY);
    } else if (this.dragLook) {
      this.look(event.clientX - this.dragLook.x, event.clientY - this.dragLook.y);
      this.dragLook = { x: event.clientX, y: event.clientY };
    }
  };

  private onMouseDown = (event: MouseEvent) => {
    if (this.active && event.button === 0 && document.pointerLockElement !== this.renderer.domElement) {
      this.dragLook = { x: event.clientX, y: event.clientY };
    }
  };

  private onMouseUp = () => { this.dragLook = null; };

  private onCanvasClick = () => {
    if (this.active && !matchMedia("(pointer: coarse)").matches) this.lockPointer();
  };

  private onTouchStart = (event: TouchEvent) => {
    if (!this.active) return;
    const touch = event.changedTouches[0];
    if (touch) this.touchLook = { id: touch.identifier, x: touch.clientX, y: touch.clientY };
  };

  private onTouchMove = (event: TouchEvent) => {
    if (!this.active || !this.touchLook) return;
    const touch = Array.from(event.changedTouches).find((item) => item.identifier === this.touchLook?.id);
    if (!touch) return;
    event.preventDefault();
    this.look((touch.clientX - this.touchLook.x) * 1.6, (touch.clientY - this.touchLook.y) * 1.6);
    this.touchLook.x = touch.clientX;
    this.touchLook.y = touch.clientY;
  };

  private onTouchEnd = (event: TouchEvent) => {
    if (Array.from(event.changedTouches).some((touch) => touch.identifier === this.touchLook?.id)) {
      this.touchLook = null;
    }
  };

  private look(x: number, y: number) {
    this.yaw -= x * 0.0024;
    this.pitch = THREE.MathUtils.clamp(this.pitch - y * 0.0024, -1.15, 1.05);
  }

  private updateAtmosphere() {
    const angle = (this.hour - 6) / 24 * Math.PI * 2;
    const elevation = Math.sin(angle);
    const daylight = smoothstep(-0.13, 0.17, elevation);
    const twilight = (1 - smoothstep(0.02, 0.36, Math.abs(elevation))) * 0.8;
    this.sunDirection.set(-Math.cos(angle) * 0.86, elevation, -0.56).normalize();
    const uniforms = (this.sky.material as THREE.ShaderMaterial).uniforms;
    uniforms.uSunDirection.value.copy(this.sunDirection);
    uniforms.uDaylight.value = daylight;
    uniforms.uTwilight.value = twilight;
    uniforms.uSkyTime.value = this.grassTime.value;
    uniforms.uCloudDetail.value = this.softwareRenderer || this.quality === "low" ? 0 : 1;

    const lightDirection = this.sunDirection.clone().multiplyScalar(elevation >= 0 ? 1 : -1);
    this.sunlight.position.copy(this.position).addScaledVector(lightDirection, 180);
    this.sunlight.target.position.copy(this.position);
    this.sunlight.target.updateMatrixWorld();
    this.sunlight.intensity = 0.26 + daylight * 1.91;
    this.sunlight.color.lerpColors(this.sunWarm, this.sunWhite, smoothstep(0.05, 0.6, elevation));
    this.sunlight.castShadow = this.shadowEnabled && elevation > 0.04;
    this.hemisphere.intensity = 0.65 + daylight * 0.85;
    this.fillLight.intensity = 0.16 + daylight * 0.12;
    if (this.scene.fog instanceof THREE.Fog) this.scene.fog.color.lerpColors(this.fogNight, this.fogDay, daylight);
    const cloudMaterial = this.clouds[0]?.sprite.material as THREE.SpriteMaterial | undefined;
    if (cloudMaterial) {
      cloudMaterial.color.lerpColors(this.cloudNight, this.cloudDay, daylight);
      cloudMaterial.opacity = 0.2 + daylight * 0.38;
    }
  }

  private clearComposer() {
    this.ssaoPass?.dispose();
    this.outputPass?.dispose();
    this.composer?.dispose();
    this.ssaoPass = null;
    this.outputPass = null;
    this.composer = null;
  }

  setQuality(quality: GraphicsQuality) {
    this.quality = quality;
    this.clearComposer();
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    this.shadowEnabled = !this.softwareRenderer && (quality === "high" || quality === "balanced" || (quality === "auto" && !coarse));
    this.renderer.shadowMap.enabled = this.shadowEnabled;
    this.vegetation.setLowDetail(quality === "low" || this.softwareRenderer || (quality === "auto" && coarse));
    this.sunlight.castShadow = this.shadowEnabled;
    const desiredRatio = quality === "low" ? 0.75 : quality === "high" ? 1.25 : 1;
    this.renderScale = this.softwareRenderer
      ? Math.min(1, 320 / Math.max(this.container.clientWidth, this.container.clientHeight))
      : Math.min(window.devicePixelRatio || 1, desiredRatio);
    this.renderer.setPixelRatio(this.renderScale);
    const shadowSize = quality === "high" ? 1024 : 768;
    if (this.sunlight.shadow.mapSize.x !== shadowSize) {
      this.sunlight.shadow.map?.dispose();
      this.sunlight.shadow.map = null;
      this.sunlight.shadow.mapSize.set(shadowSize, shadowSize);
    }
    if (quality === "high" && this.aoSupported) {
      try {
        this.composer = new EffectComposer(this.renderer);
        this.composer.addPass(new RenderPass(this.scene, this.camera));
        this.ssaoPass = new SSAOPass(this.scene, this.camera, this.container.clientWidth, this.container.clientHeight, 16);
        this.ssaoPass.kernelRadius = 5;
        this.ssaoPass.minDistance = 0.003;
        this.ssaoPass.maxDistance = 0.08;
        this.composer.addPass(this.ssaoPass);
        this.outputPass = new OutputPass();
        this.composer.addPass(this.outputPass);
        this.composer.setPixelRatio(this.renderScale);
        this.composer.setSize(this.container.clientWidth, this.container.clientHeight);
      } catch (error) {
        console.warn("Ambient occlusion is unavailable on this device", error);
        this.clearComposer();
      }
    }
    this.performanceTime = 0;
    this.performanceFrames = 0;
    this.updateAtmosphere();
  }

  setTime(hour: number) {
    this.hour = ((hour % 24) + 24) % 24;
    this.updateAtmosphere();
    this.options.onPosition({ x: this.position.x, z: this.position.z, bearing: ((-THREE.MathUtils.radToDeg(this.yaw) % 360) + 360) % 360, hour: this.hour });
  }

  setDayNightCycle(enabled: boolean) {
    this.cycleEnabled = enabled;
  }

  graphicsCapabilities() {
    return { ambientOcclusion: this.aoSupported, softwareRendering: this.softwareRenderer };
  }

  private animate = (time: number) => {
    if (this.disposed) return;
    const elapsed = this.lastTime ? (time - this.lastTime) / 1000 : 0;
    const delta = Math.min(elapsed, 0.2);
    this.lastTime = time;
    if (!this.active) {
      this.frame = requestAnimationFrame(this.animate);
      return;
    }
    this.performanceTime += Math.min(elapsed, 1);
    this.performanceFrames += 1;
    if (this.performanceTime >= 4) {
      if (this.quality === "auto" && this.performanceFrames / this.performanceTime < 22) {
        if (this.shadowEnabled) {
          this.shadowEnabled = false;
          this.renderer.shadowMap.enabled = false;
        } else {
          const minimum = this.softwareRenderer ? 230 / Math.max(this.container.clientWidth, this.container.clientHeight) : 0.55;
          if (this.renderScale > minimum) {
            this.renderScale = Math.max(minimum, this.renderScale * 0.8);
            this.renderer.setPixelRatio(this.renderScale);
          }
        }
      }
      this.performanceTime = 0;
      this.performanceFrames = 0;
    }
    this.grassTime.value = time / 1000;
    if (this.cycleEnabled) this.hour = (this.hour + Math.min(elapsed, 1) * 24 / 1080) % 24;
    this.waterTexture.offset.x = (time / 180000) % 1;
    this.waterNormalTexture.offset.y = (time / 240000) % 1;

    if (this.active) {
      let forward = (this.keys.has("w") || this.keys.has("arrowup") ? 1 : 0) -
        (this.keys.has("s") || this.keys.has("arrowdown") ? 1 : 0) - this.touchMovement.y;
      let sideways = (this.keys.has("d") || this.keys.has("arrowright") ? 1 : 0) -
        (this.keys.has("a") || this.keys.has("arrowleft") ? 1 : 0) + this.touchMovement.x;
      const amount = Math.hypot(forward, sideways);
      if (amount > 1) {
        forward /= amount;
        sideways /= amount;
      }
      const moving = Math.hypot(forward, sideways) > 0.03;
      if (moving) {
        const speed = this.keys.has("shift") ? 11 : 5.7;
        const waterSpeed = lakeAmount(this.position.x, this.position.z) > 0.6 && !Number.isFinite(bridgeSurface(this.position.x, this.position.z)) ? 0.65 : 1;
        const moveX = (-Math.sin(this.yaw) * forward + Math.cos(this.yaw) * sideways) * speed * waterSpeed * delta;
        const moveZ = (-Math.cos(this.yaw) * forward - Math.sin(this.yaw) * sideways) * speed * waterSpeed * delta;
        const steps = Math.max(1, Math.ceil(Math.hypot(moveX, moveZ) / 0.2));
        for (let step = 0; step < steps; step += 1) {
          const nextX = this.position.x + moveX / steps;
          if (!houseWallBlocks(nextX, this.position.z) && !villageObstacleBlocks(nextX, this.position.z) && !sceneryBlocks(nextX, this.position.z)) this.position.x = nextX;
          const nextZ = this.position.z + moveZ / steps;
          if (!houseWallBlocks(this.position.x, nextZ) && !villageObstacleBlocks(this.position.x, nextZ) && !sceneryBlocks(this.position.x, nextZ)) this.position.z = nextZ;
        }
        this.movingTime += delta * (this.keys.has("shift") ? 12 : 8);
      }
      const surface = Math.max(terrainHeight(this.position.x, this.position.z), WATER_LEVEL - 0.85, bridgeSurface(this.position.x, this.position.z));
      const bob = moving ? Math.sin(this.movingTime) * 0.055 : 0;
      const targetY = surface + 2.2 + bob;
      this.position.y = THREE.MathUtils.lerp(this.position.y, targetY, Math.min(1, delta * 9));
      this.updateTerrain();
      this.vegetation.update(this.position.x, this.position.z);
      this.updateTrail();
    }

    this.camera.position.copy(this.position);
    this.camera.rotation.set(this.pitch, this.yaw, 0, "YXZ");
    this.sky.position.copy(this.position);
    this.updateAtmosphere();
    this.rotors.forEach((rotor) => { rotor.rotation.x += delta * 0.3; });
    this.clouds.forEach(({ sprite, x, y, z, phase }) => {
      sprite.position.set(this.position.x + x + Math.sin(time / 50000 + phase) * 12, this.position.y + y, this.position.z + z);
    });
    if (this.composer) this.composer.render(delta);
    else this.renderer.render(this.scene, this.camera);

    if (time - this.lastHud > 180) {
      this.lastHud = time;
      this.options.onPosition({
        x: this.position.x,
        z: this.position.z,
        bearing: ((-THREE.MathUtils.radToDeg(this.yaw) % 360) + 360) % 360,
        hour: this.hour,
      });
    }
    this.frame = requestAnimationFrame(this.animate);
  };

  setActive(active: boolean) {
    this.active = active;
    if (!active) {
      this.keys.clear();
      this.touchMovement = { x: 0, y: 0 };
      this.dragLook = null;
      if (document.pointerLockElement === this.renderer.domElement) document.exitPointerLock();
    }
  }

  lockPointer() {
    if (this.disposed || document.pointerLockElement === this.renderer.domElement) return;
    try {
      const result = this.renderer.domElement.requestPointerLock();
      if (result && typeof result.catch === "function") result.catch(() => undefined);
    } catch {
      // Pointer lock is optional; keyboard and touch movement still work without it.
    }
  }

  setTouchMovement(x: number, y: number) {
    this.touchMovement = { x, y };
  }

  reset() {
    this.position.set(START_POSITION.x, terrainHeight(START_POSITION.x, START_POSITION.z) + 2.2, START_POSITION.z);
    this.yaw = 0;
    this.pitch = -0.1;
    this.updateTerrain();
    this.vegetation.update(this.position.x, this.position.z);
    this.updateTrail();
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frame);
    window.removeEventListener("resize", this.onResize);
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    window.removeEventListener("mouseup", this.onMouseUp);
    document.removeEventListener("pointerlockchange", this.onPointerLockChange);
    document.removeEventListener("mousemove", this.onMouseMove);
    this.renderer.domElement.removeEventListener("click", this.onCanvasClick);
    this.renderer.domElement.removeEventListener("mousedown", this.onMouseDown);
    this.renderer.domElement.removeEventListener("touchstart", this.onTouchStart);
    this.renderer.domElement.removeEventListener("touchmove", this.onTouchMove);
    this.renderer.domElement.removeEventListener("touchend", this.onTouchEnd);
    this.renderer.domElement.removeEventListener("touchcancel", this.onTouchEnd);
    if (document.pointerLockElement === this.renderer.domElement) document.exitPointerLock();
    this.terrain.forEach((tile) => tile.geometry.dispose());
    if (this.trail) {
      this.trail.geometry.dispose();
      (this.trail.material as THREE.Material).dispose();
    }
    this.vegetation.dispose();
    this.resources.forEach((resource) => resource.dispose());
    this.clearComposer();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}