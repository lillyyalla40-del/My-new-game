import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";

const BRIDGE_START = -8;
const BRIDGE_END = 90;
const BRIDGE_Z = -89;
const BRIDGE_HALF_WIDTH = 2.35;
const RUIN_X = -210;
const RUIN_Z = -12;

export const LANDMARKS = [
  { name: "Old Arch", x: RUIN_X, z: RUIN_Z },
  { name: "Highstone", x: 275, z: -65 },
];
export const BRIDGE_MAP = { fromX: BRIDGE_START, toX: BRIDGE_END, z: BRIDGE_Z };

function deckHeight(x: number) {
  const t = THREE.MathUtils.clamp((x - BRIDGE_START) / (BRIDGE_END - BRIDGE_START), 0, 1);
  return 1.65 + t * 0.35 + Math.sin(t * Math.PI) * 0.25;
}

export function bridgeSurface(x: number, z: number) {
  if (x < BRIDGE_START || x > BRIDGE_END || Math.abs(z - BRIDGE_Z) > BRIDGE_HALF_WIDTH) return -Infinity;
  return deckHeight(x) + 0.1;
}

export function sceneryGroundClear(x: number, z: number, margin = 0) {
  return (x > BRIDGE_START - margin && x < BRIDGE_END + margin && Math.abs(z - BRIDGE_Z) < BRIDGE_HALF_WIDTH + margin) ||
    Math.hypot(x - RUIN_X, z - RUIN_Z) < 9 + margin || Math.hypot(x - 275, z + 65) < 5 + margin;
}

export function sceneryBlocks(x: number, z: number) {
  const onBridgeSide = x > BRIDGE_START + 1 && x < BRIDGE_END - 1 &&
    Math.abs(Math.abs(z - BRIDGE_Z) - BRIDGE_HALF_WIDTH) < 0.45;
  if (onBridgeSide) return true;
  for (const side of [-1, 1]) {
    if (Math.hypot(x - (RUIN_X + side * 3.2), z - RUIN_Z) < 1.35) return true;
  }
  return false;
}

export function createScenery(heightAt: (x: number, z: number) => number, woodMap: THREE.Texture, stoneMap: THREE.Texture) {
  const group = new THREE.Group();
  group.name = "world-landmarks";
  const wood = new THREE.MeshStandardMaterial({ color: "#c8b69b", map: woodMap, roughness: 0.96 });
  const stone = new THREE.MeshStandardMaterial({ color: "#acae9e", map: stoneMap, roughness: 1, bumpMap: stoneMap, bumpScale: 0.05 });
  const resources: Array<THREE.BufferGeometry | THREE.Material> = [wood, stone];
  const dummy = new THREE.Object3D();

  const planks = new THREE.BoxGeometry(0.95, 0.18, BRIDGE_HALF_WIDTH * 2);
  const plankCount = Math.floor(BRIDGE_END - BRIDGE_START);
  const plankMesh = new THREE.InstancedMesh(planks, wood, plankCount);
  for (let i = 0; i < plankCount; i += 1) {
    const x = BRIDGE_START + i + 0.5;
    dummy.position.set(x, deckHeight(x), BRIDGE_Z);
    dummy.rotation.set(0, 0, (deckHeight(x + 0.5) - deckHeight(x - 0.5)));
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    plankMesh.setMatrixAt(i, dummy.matrix);
  }
  plankMesh.castShadow = true;
  plankMesh.receiveShadow = true;
  plankMesh.instanceMatrix.needsUpdate = true;
  plankMesh.computeBoundingSphere();
  group.add(plankMesh);
  resources.push(planks);

  const posts = new THREE.BoxGeometry(0.18, 1.35, 0.18);
  const rails = new THREE.BoxGeometry(4.1, 0.13, 0.14);
  const railCount = Math.floor((BRIDGE_END - BRIDGE_START) / 4);
  const postMesh = new THREE.InstancedMesh(posts, wood, (railCount + 1) * 2);
  const railMesh = new THREE.InstancedMesh(rails, wood, railCount * 2);
  let postIndex = 0;
  let railIndex = 0;
  for (const side of [-1, 1]) {
    for (let i = 0; i <= railCount; i += 1) {
      const x = BRIDGE_START + i * 4;
      dummy.position.set(x, deckHeight(x) + 0.72, BRIDGE_Z + side * BRIDGE_HALF_WIDTH);
      dummy.rotation.set(0, 0, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      postMesh.setMatrixAt(postIndex++, dummy.matrix);
      if (i < railCount) {
        const middle = x + 2;
        dummy.position.set(middle, deckHeight(middle) + 1.26, BRIDGE_Z + side * BRIDGE_HALF_WIDTH);
        dummy.rotation.set(0, 0, (deckHeight(x + 4) - deckHeight(x)) / 4);
        dummy.updateMatrix();
        railMesh.setMatrixAt(railIndex++, dummy.matrix);
      }
    }
  }
  postMesh.castShadow = railMesh.castShadow = true;
  postMesh.receiveShadow = railMesh.receiveShadow = true;
  postMesh.instanceMatrix.needsUpdate = railMesh.instanceMatrix.needsUpdate = true;
  postMesh.computeBoundingSphere();
  railMesh.computeBoundingSphere();
  group.add(postMesh, railMesh);
  resources.push(posts, rails);

  const supports = new THREE.CylinderGeometry(0.17, 0.24, 3.6, 7);
  const supportMesh = new THREE.InstancedMesh(supports, wood, 24);
  let supportIndex = 0;
  for (const side of [-1, 1]) {
    for (let i = 0; i < 12; i += 1) {
      const x = BRIDGE_START + 4 + i * 8;
      dummy.position.set(x, deckHeight(x) - 1.75, BRIDGE_Z + side * 1.9);
      dummy.rotation.set(0, 0, 0);
      dummy.updateMatrix();
      supportMesh.setMatrixAt(supportIndex++, dummy.matrix);
    }
  }
  supportMesh.castShadow = true;
  supportMesh.instanceMatrix.needsUpdate = true;
  supportMesh.computeBoundingSphere();
  group.add(supportMesh);
  resources.push(supports);

  const ruinPieces: THREE.BufferGeometry[] = [];
  const ruinGround = heightAt(RUIN_X, RUIN_Z);
  const addRuin = (geometry: THREE.BufferGeometry, x: number, y: number, z: number, rotation = 0) => {
    geometry.rotateY(rotation);
    geometry.translate(RUIN_X + x, ruinGround + y, RUIN_Z + z);
    ruinPieces.push(geometry);
  };
  for (const side of [-1, 1]) {
    addRuin(new THREE.CylinderGeometry(0.9, 1.12, 5.4, 7), side * 3.2, 2.7, 0, side * 0.16);
    addRuin(new THREE.CylinderGeometry(1.3, 1.4, 0.5, 7), side * 3.2, 0.25, 0);
    addRuin(new THREE.BoxGeometry(2.5, 0.65, 1.7), side * 3.2, 5.55, 0, side * 0.06);
  }
  addRuin(new THREE.BoxGeometry(6.3, 0.8, 1.4), 0, 6.25, 0, -0.035);
  for (let i = 0; i < 7; i += 1) {
    const rock = new THREE.DodecahedronGeometry(0.55 + (i % 3) * 0.22, 0);
    rock.scale(1.25, 0.55, 0.85);
    addRuin(rock, (i - 3) * 1.5, 0.25, 2.4 + (i % 2) * 0.9, i * 0.7);
  }
  const normalizedRuinPieces = ruinPieces.map((geometry) => geometry.index ? geometry.toNonIndexed() : geometry);
  const ruinGeometry = mergeGeometries(normalizedRuinPieces);
  normalizedRuinPieces.forEach((geometry) => geometry.dispose());
  ruinPieces.forEach((geometry) => geometry.dispose());
  if (ruinGeometry) {
    const ruins = new THREE.Mesh(ruinGeometry, stone);
    ruins.castShadow = true;
    ruins.receiveShadow = true;
    group.add(ruins);
    resources.push(ruinGeometry);
  }

  const markerGround = heightAt(275, -65);
  const markerGeometry = new THREE.CylinderGeometry(0.6, 1.5, 7.5, 6);
  markerGeometry.translate(275, markerGround + 3.75, -65);
  const marker = new THREE.Mesh(markerGeometry, stone);
  marker.castShadow = true;
  marker.receiveShadow = true;
  group.add(marker);
  resources.push(markerGeometry);
  return { group, resources };
}